# SDK 二进制放置说明

本目录**故意为空**。大恒（Daheng Imaging）GalaxySDK 的运行时 DLL 和 Microsoft VC++ 运行时 DLL 受厂商许可约束，且体积较大，因此**不放在 Git 仓库中**（见根目录 `.gitignore`）。

只有「真实相机实时采集」才需要这些文件。照片演示、单张图片解算、网页看板都不需要 SDK。

## 方式一：放进项目（推荐，便于 U 盘携带）

把大恒 GalaxySDK 安装目录下 `APIDll/Win64/` 的全部内容复制到本项目的 `sdk/Win64/`：

```
sdk/
├── README.md          (本文件)
└── Win64/             ← 自建，全部由 .gitignore 排除
    ├── GxIAPI.dll
    ├── DxImageProc.dll
    ├── GxIAPICPPEx.dll
    ├── GxIAPICPP.dll
    ├── AxNICCfg.dll
    ├── mfc90.dll
    ├── msvcp*.dll / msvcr*.dll
    └── Microsoft.VC90.*.manifest
```

`galaxy_sdk_root.m` 会自动优先找到这个目录，并把该路径加入 `PATH` 以加载依赖 DLL。

## 方式二：使用已安装的 SDK

设置环境变量指向 DLL 所在目录（或 SDK 根目录），无需复制文件：

```bat
set ARUCO_SDK_ROOT=C:\GalaxySDK\APIDll\Win64
RUN.bat
```

```bash
export ARUCO_SDK_ROOT=/path/to/galaxy/sdk
bash run_mac.sh check
```

也可以在 `config.json` 的 `sdk.root` 中填写。查找优先级为：

1. 环境变量 `ARUCO_SDK_ROOT` / `GALAXYSDK_ROOT`
2. `config.json` 的 `sdk.root`
3. 项目内 `sdk/Win64/`
4. 常见安装目录（Windows）
5. 系统 `PATH`

## 验证

```matlab
cd('.../matlab')
S = galaxy_sdk_root();
disp(S.found)      % 应为 1
disp(S.source)     % 命中的 DLL 路径
```

或运行 `CHECK.bat` / `bash run_mac.sh check`，预检报告里 `GalaxySDK GxIAPI.dll` 应显示 `ready`。

## 许可提醒

这些 DLL 仅供已合法取得大恒 GalaxySDK 的用户在本机使用。**请勿把它们提交到公开仓库或随项目再分发**；如需分发，请遵循大恒图像的 SDK 许可条款。

`gxi_api.h`（`matlab/` 下）是本仓库为 MATLAB `loadlibrary` 编写的最小头文件声明，随源码一起提供。
