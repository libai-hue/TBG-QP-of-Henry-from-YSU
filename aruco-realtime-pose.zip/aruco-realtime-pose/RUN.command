#!/usr/bin/env bash
# macOS double-click entry. FAT32 USB drives do not keep executable bits,
# so if Finder refuses to open it, run this once in Terminal:
#   chmod +x RUN.command
# Alternatively, always works without chmod:
#   bash run_mac.sh
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
exec bash run_mac.sh "$@"
