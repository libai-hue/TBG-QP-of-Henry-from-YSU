@echo off
rem Compatibility wrapper: the single entry point is RUN.bat
rem (old name kept so existing shortcuts still work)
call "%~dp0RUN.bat" %*
