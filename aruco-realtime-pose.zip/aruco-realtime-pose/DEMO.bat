@echo off
rem Double-click to run the photo demo (no camera / SDK needed)
call "%~dp0RUN.bat" demo
