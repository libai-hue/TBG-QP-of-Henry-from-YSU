# aruco-realtime-pose

**用纯 MATLAB 代码实时计算两枚 ArUco 标记之间的三维相对位置。**

从大恒（Daheng Imaging / Galaxy）相机连续取帧，每一帧独立完成「检测 → 解码 → PnP 位姿解算 → 相对位姿输出」，实测约 20 fps。检测与解算全部在 MATLAB 内完成，**运行时不依赖 Python、OpenCV 或 MEX**。

![纯 MATLAB 解算出的两标记相对位置](docs/images/native_pose.png)

| 输出 | 含义 |
|---|---|
| `dX / dY / dZ` | 物体 1 相对物体 0 的三维位移（mm），在物体 0 坐标系下 |
| `distance_mm` | 两标记中心直线距离（mm） |
| `rotation_deg` | 两标记坐标系之间的相对转角（度） |
| `T_A_B` | 完整 4×4 齐次变换矩阵 |
| `frame` / `fps` / `ids` | 帧号、实时帧率、检出的 ID |

实时运行效果（HUD 窗口）：![实时 HUD](docs/images/realtime_hud.png)

---

## 特性

- **纯 M 实现**：自适应阈值 → 轮廓 → 多起点 Douglas-Peucker 四边形 → 透视归一化 → 码本解码 → 单应性/PnP → 相对位姿，全部为 MATLAB 代码。
- **逐帧可复用接口**：`aruco_solve_frame(frame, K, opts)` 静态图与实时循环共用同一套算法。
- **一键启动**：Windows 双击 `RUN.bat` / `CHECK.bat` / `DEMO.bat`；macOS/Linux 用 `bash run_mac.sh`。
- **自动环境预检**：换电脑后明确列出缺少的组件，而不是让错误藏在 MATLAB 深处。
- **跨电脑参数化**：所有机器相关参数集中在 `config.json`，自动探测 MATLAB 与 SDK 位置。
- **实时看板**：`results/realtime_dashboard.html` 每 300 ms 刷新；`file://` 双击打开也能工作，无需本地服务器。
- **无相机也能跑**：照片演示模式验证整条识别链路，不需要相机或 SDK。

---

## 快速开始

### Windows

```
双击 CHECK.bat     环境预检 + 自检（不占相机，换电脑后第一步）
双击 RUN.bat       正式启动（相机在线 → 实时；离线 → 照片演示并给出排查指引）
双击 DEMO.bat      只跑照片演示
```

或命令行：`RUN.bat check` / `RUN.bat demo` / `RUN.bat live`。

### macOS / Linux

`.bat` 不能在 macOS 上运行，但**识别与解算核心完全跨平台**：

```bash
bash run_mac.sh                       # 照片演示（默认）
bash run_mac.sh check                 # 环境预检 + 自检
bash run_mac.sh image /path/photo.jpg # 对一张图片解算相对位置
```

也可双击 `RUN.command`（若提示权限，先 `chmod +x RUN.command`）。
真实相机实时采集目前仅支持 Windows，详见「已知限制」。

### 在 MATLAB 命令窗口里

```matlab
cd('.../aruco-realtime-pose/matlab')
quickstart                                   % 自检
R = aruco_native_pose();                     % 单张照片解算 + 画图
I = imread('../sample/two_markers_photo.jpg');
C = project_config();
R = aruco_solve_frame(I, C.K, true);         % 任意一帧
start_realtime                               % 实时循环（需相机，Ctrl-C 停止）
```

运行时保持控制台窗口开着；按 `Ctrl-C` 或关闭即停止。看板会自动在浏览器打开。

---

## 环境要求

| 依赖 | 说明 |
|---|---|
| MATLAB | R2018b 或更新，**64 位** |
| Image Processing Toolbox | 必需（`adaptthresh` / `bwboundaries` / `imresize`） |
| C/C++ 编译器 | 仅实时相机需要：`mex -setup C++` 选 VS2022 / MinGW / Xcode Clang，供 `loadlibrary` 生成 thunk |
| 大恒 GalaxySDK | 仅实时相机需要，见下方说明 |
| 相机 | 大恒 MER 系列（本项目实测 MER-132-30UM，1292×964，Mono8） |
| 标记 | `DICT_4X4_50` 的 ID 0 与 ID 1，物理边长 50 mm |

> ### ⚠️ SDK 二进制不在本仓库
>
> 出于许可与体积考虑，大恒 GalaxySDK 的 `GxIAPI.dll` 及 VC++ 运行时 DLL **不会上传**。
> 克隆后请按 [`sdk/README.md`](sdk/README.md) 自行放置，或设置环境变量 `ARUCO_SDK_ROOT` 指向已安装的 SDK。
> 只有「真实相机实时采集」需要它；照片演示 / 单张图片解算完全不需要 SDK。

相机是独占设备：运行实时循环时不要打开 GalaxyView、其它采集程序或第二个实时实例。

---

## 目录结构

```
aruco-realtime-pose/
├── README.md                  本文件
├── .gitignore / .gitattributes
├── config.json                ★ 相机与检测参数（换相机只改这里）
├── RUN.bat / CHECK.bat / DEMO.bat / start_realtime.bat
├── run_mac.sh / RUN.command   macOS 入口
├── matlab/
│   ├── aruco_solve_frame.m    ★ 核心：逐帧 solveFrame(frame, K, opts)
│   ├── aruco_dict_4x4_50.m    DICT_4X4_50 码本常量（50×16）
│   ├── aruco_native_pose.m    静态入口：一张图跑通链路并画图
│   ├── run_project.m          统一入口：预检 + 实时 / 演示 / 自检
│   ├── run_mac.m              macOS / Linux 入口
│   ├── preflight.m            环境预检
│   ├── project_config.m       读 config.json，集中所有参数
│   ├── galaxy_sdk_root.m      自动定位 SDK（环境变量 / 项目内 / 常见目录 / PATH）
│   ├── camera_count.m         轻量相机枚举（不打开设备）
│   ├── write_live.m           每帧原子写 .json 与 .js
│   ├── open_image.m           跨平台打开标注图
│   ├── quickstart.m           一键自检
│   ├── realtime_pose_matlab.m 可配置实时循环
│   ├── start_realtime.m       无限循环 + HUD + 数据输出
│   ├── cam_probe.m / scan_exposure.m  诊断工具
│   ├── gx_camera.m            大恒相机 loadlibrary 封装
│   └── gxi_api.h              loadlibrary 头文件（须与 gx_camera.m 同目录）
├── sample/two_markers_photo.jpg
├── results/
│   ├── realtime_dashboard.html  实时看板（运行时数据由 .gitignore 排除）
│   └── realtime_live.sample.json  输出格式样例
├── docs/
│   ├── images/                 文档截图
│   ├── USB_PORTABLE.md         U 盘便携版说明
│   └── GITHUB_UPLOAD.md        上传到 GitHub 的步骤
├── sdk/README.md              如何放置 SDK 二进制
├── tools/gui_driver.py        可选：Win32 GUI 驱动 / 截屏留证
└── vs_cpp/aruco_dict_4x4_50.h C++ 码本常量（VS 侧实现预留）
```

所有脚本通过 `fileparts(mfilename('fullpath'))` 定位项目根，**整体克隆/复制到任意路径都可用**。

---

## 配置

`config.json` 集中所有机器相关参数，改完保存即生效，无需改 `.m` 文件：

| 字段 | 默认 | 说明 |
|---|---|---|
| `camera.K` | fx=fy=2133.3, cx=646, cy=482 | **换相机型号必须重新标定**；`UseRealK=false` 时用平面单应性自标定 |
| `camera.exposure_us` | 50000 | 曝光（µs），按现场光圈调整 |
| `camera.gain_code` | 400 | 设备 raw 增益 |
| `camera.gain_feature_id` | `20001393` | SDK 增益功能码，换型号可能不同 |
| `detection.max_dim` | 720 | 检测前降采样最大边长；0 = 不降采样 |
| `detection.tag_size_mm` | 50.0 | **标记物理边长**，直接影响所有 mm 数值 |
| `detection.dictionary` / `marker_ids` | DICT_4X4_50 / [0,1] | 码本与目标 ID |
| `sdk.root` | `""` | 留空自动探测；可填 SDK 根目录或 DLL 目录 |

也可用环境变量 `ARUCO_SDK_ROOT`（优先）或 `ARUCO_MATLAB_EXE` 覆盖自动探测结果。
看板显示的 `K.fx / 曝光 / 增益` 从每帧数据的 `cfg` 字段读取，不会显示另一台机器的旧参数。

---

## 算法

`aruco_solve_frame.m` 每帧执行：

1. `adaptthresh` + `imbinarize` 自适应二值化，形态学去噪；
2. `bwboundaries` 提取暗区轮廓；
3. **多起点 Douglas-Peucker** 把闭合轮廓简化为凸四边形（避免轮廓起点落在直边中间多切一个顶点）；
4. 单应性把四边形透视归一化到 6×6，采样内部 4×4 位；
5. 对「原码 / 反码」×「4 个旋转」共 8 种组合与 `DICT_4X4_50` 比对，取最小汉明距离（≤2 接受）；
6. 由平面单应性自标定等效焦距，或使用给定内参 `K`；
7. 单应性分解求 PnP 位姿 `T_C_A`、`T_C_B`；
8. `T_A_B = T_C_A \ T_C_B`，输出位移、距离、相对转角。

实现要点：码本由公开的 OpenCV 字典定义导出为**行优先** 16 位，MATLAB `code(:)` 是列优先，比较前必须 `reshape(code.',1,[])`；打印件可能是反相极性，解码须同时试原码与反码。

---

## 输出数据格式

实时循环每帧原子写 `results/realtime_live.json` 与 `realtime_live.js`（内容一致，后者供 `file://` 看板读取）：

```json
{
  "running": true, "demo": false, "frame": 2229, "valid": 2210,
  "fps": 20.2, "ok": true,
  "dX_mm": 111.7, "dY_mm": -5.0, "dZ_mm": -4.6,
  "distance_mm": 111.9, "rotation_deg": 1.1,
  "ids": [0, 1], "engine": "MATLAB pure M realtime",
  "cfg": {"fx": 2133.3, "exposure_us": 50000, "gain": 400, "tag_mm": 50, "max_dim": 720}
}
```

`ok=false` 表示该帧未同时检出两枚标记；`demo=true` 表示数值来自示例照片、不是实时帧；`running=false` 表示循环已停止。

---

## 已知限制

- **macOS / Linux 暂不支持真实相机采集**：`gx_camera.m` 依赖 Windows 的 `GxIAPI.dll` + `loadlibrary` thunk。大恒官方提供 macOS 版 Galaxy SDK，移植相机驱动后即可复用检测与解算核心。照片演示、单图解算、看板在 macOS 上可用。
- 内参 `K` 默认是**标称值**，未经棋盘格实测标定；`dZ` 对焦距误差敏感。正式测量前请标定后写入 `config.json`。
- 静态照片版用平面单应性自标定焦距，两标记不共面时会退化；照片数值只用于验证链路，不作测量结果。
- 实时帧率约 20 fps（`max_dim=720`），相机全幅上限 30 fps；减小 `max_dim` 可提速。
- VS C++ 侧独立实现尚未完成（本机无独立 OpenCV C++ 开发库），`vs_cpp/` 仅预留码本头文件。

---

## 常见问题

| 现象 | 处理 |
|---|---|
| `RUN.bat` 报 `MATLAB not found` | 装 64 位 MATLAB，或编辑 `RUN.bat` 顶部 `ARUCO_MATLAB_EXE` |
| 预检 `C++ compiler ... missing` | 装编译器后执行 `mex -setup C++`；仅实时相机需要 |
| 预检 `Image Processing Toolbox ... missing` | 安装该工具箱，否则照片演示也跑不了 |
| `Cannot find GxIAPI.dll` | 按 `sdk/README.md` 放置 DLL，或设 `ARUCO_SDK_ROOT` |
| `AcquisitionStart -1001` | 相机被 GalaxyView / 其它程序占用，关闭后重试 |
| `没有找到设备` / 枚举 0 台 | 重新插拔相机 USB 线；用 `cam_probe.m` 确认恢复 |
| 一直 `no detection` | 检查两枚标记同框、亮度；运行 `scan_exposure` 选曝光/增益 |
| 看板显示「演示模式」 | 数值来自示例照片，不是实时帧 |
| 解出的 ID 不对 | 多为码本位序问题，确认使用本仓库的 `aruco_dict_4x4_50.m` |

---

## 上传到 GitHub

见 [`docs/GITHUB_UPLOAD.md`](docs/GITHUB_UPLOAD.md)。**上传前务必确认没有提交 `sdk/Win64/` 下的任何 DLL。**

## 许可

本仓库尚未指定开源许可。若要公开发布，请自行选择（如 MIT / Apache-2.0 / GPL-3.0）并添加 `LICENSE` 文件。
注意：大恒 GalaxySDK 的 DLL 与头文件受厂商许可约束，不包含在本仓库中；码本常量来自公开的 OpenCV `DICT_4X4_50` 字典定义。

## 致谢

- 大恒图像 GalaxySDK（相机 C API）
- OpenCV `DICT_4X4_50` 字典定义（导出为纯数据常量）
- MATLAB Image Processing Toolbox
