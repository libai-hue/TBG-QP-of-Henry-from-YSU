# 上传到 GitHub

整理后的仓库目录已经是可直接 `git init` 的状态：`.gitignore` 排除了专有 DLL、运行时产物和本机截图，`.gitattributes` 锁定了 `.bat`（CRLF）与 `.sh`（LF）的换行符。

## 1. 上传前检查（重要）

```bash
cd aruco-realtime-pose

# 确认没有 DLL / 运行时产物 / 桌面截图
find . -name "*.dll" -o -name "realtime_live.json" -o -name "gui_steps" | head
```

以上命令应**无输出**。如果之前把 SDK DLL 放进过 `sdk/Win64/`，`.gitignore` 已排除该目录，但请再确认一次 `git status` 里没有它。

同时检查是否含有本机信息：

```bash
grep -rIn "C:\\Users\\" --include=*.m --include=*.md --include=*.bat --include=*.sh . | head
```

应无命中（SDK 的通用安装候选路径如 `C:\Program Files\...` 属正常）。

## 2. 初始化并首次提交

```bash
git init
git add .
git status                 # 核对即将提交的文件清单
git commit -m "Initial commit: realtime ArUco relative pose in pure MATLAB"
git branch -M main
```

`git status` 里应该只有源码、文档、示例图、看板 HTML 和配置，**不应出现**：

- `sdk/Win64/` 下任何 `.dll` / `.manifest`
- `results/realtime_live.json` / `.js`、`*_result.json`
- `results/gui_steps/` 截图、`*_preview.png`、`*_tmp*.png`
- `*.log` / `*.tmp` / `__pycache__`

## 3. 关联远程仓库并推送

在 GitHub 上新建一个**空仓库**（不要勾选初始化 README / LICENSE，避免冲突），然后：

```bash
git remote add origin https://github.com/<你的用户名>/<仓库名>.git
git push -u origin main
```

若使用 SSH：`git remote add origin git@github.com:<用户名>/<仓库名>.git`

## 4. 建议补齐

- **LICENSE**：仓库目前未指定开源许可。在 GitHub 网页上点「Add file → Create new file → LICENSE」，选择 MIT / Apache-2.0 / GPL-3.0 后再同步到本地。公开仓库若无 LICENSE，默认是「保留所有权利」，别人不能合法复用。
- **仓库描述 / topics**：例如 `matlab`, `aruco`, `pose-estimation`, `computer-vision`, `daheng-camera`。
- **Release / 附件**：如需分发可运行的便携包，把不含 DLL 的压缩包作为 Release 附件，并在说明里指引用户阅读 `sdk/README.md` 自行放置 DLL。
- **不要**把示例照片换成含人脸、工牌、屏幕敏感信息的图片。

## 5. 常见误传处理

如果 DLL 已经被提交进历史（不只是工作区），仅删除文件不够，需要清理历史：

```bash
git filter-repo --path sdk/Win64 --invert-paths
# 或 BFG Repo-Cleaner
```

然后强制推送并**立即轮换任何可能泄露的凭据**。最好的做法是从一开始就别提交它们。

## 6. 克隆后他人如何运行

```bash
git clone https://github.com/<用户名>/<仓库名>.git
cd <仓库名>
# Windows
CHECK.bat
RUN.bat
# macOS / Linux
bash run_mac.sh check
bash run_mac.sh
```

克隆后默认只能跑照片演示；要接真实相机，按 `sdk/README.md` 自备大恒 GalaxySDK 的 DLL，并确认目标机器装有 MATLAB + Image Processing Toolbox（实时相机还需 C++ 编译器）。
