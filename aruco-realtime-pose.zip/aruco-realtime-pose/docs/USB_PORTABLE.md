# U 盘便携版说明

本项目可以整体放到 U 盘，插到另一台 Windows 电脑直接运行；路径全部相对，盘符变化不影响。

## 准备 U 盘

1. 把整个项目文件夹复制到 U 盘根目录。
2. 如需**不安装 GalaxySDK 就能接相机**，按 [`../sdk/README.md`](../sdk/README.md) 把厂商 DLL 放进 `sdk/Win64/`。
   （这些 DLL 不在 Git 仓库里，U 盘里可以自备一份自用；公开分发请遵守厂商许可。）
3. 可选：在 U 盘根目录放一份指向本文件的说明。

## 在另一台电脑上

| 操作 | 效果 |
|---|---|
| 双击 `CHECK.bat` | 环境预检 + 自检，明确列出这台电脑缺什么（不占相机） |
| 双击 `RUN.bat` | 相机在线 → 实时识别；离线/环境不全 → 打印排查指引并自动跑照片演示 |
| 双击 `DEMO.bat` | 只跑照片演示，完全不碰相机、不需要 SDK |

看板会自动在浏览器打开，也可双击 `results/realtime_dashboard.html`。实时模式保持黑色控制台窗口开着，按 `Ctrl-C` 或关闭即停止。

## 目标电脑必须自行具备

- 64 位 MATLAB（R2018b+）
- Image Processing Toolbox
- 实时相机模式：C/C++ 编译器（MATLAB 里执行 `mex -setup C++`）、大恒相机 + USB 线、两枚 `DICT_4X4_50` 的 ID 0 / ID 1 标记（边长 50 mm）

MATLAB 本体和工具箱因体积与许可无法随 U 盘携带。若 MATLAB 不在常见安装路径，编辑 `RUN.bat` 顶部的 `ARUCO_MATLAB_EXE`。

## 注意事项

- 相机是独占设备：运行时不要打开 GalaxyView 或其它采集程序。
- 相机未插好会显示 `CAMERA OFFLINE`，这是硬件问题，重新插拔 USB 即可；期间自动跑照片演示。
- 若 U 盘为 FAT32，可执行位不会保留，所以 macOS 请用 `bash run_mac.sh`（而不是依赖双击 `RUN.command`）。
- 换相机型号：编辑 `config.json` 的 `camera.K`（内参）与 `detection.tag_size_mm`（标记边长），保存即可，不用改代码。
- 若目标电脑没有网络或权限受限，把整个文件夹复制到有写权限的本地目录再运行（`results/` 需要可写）。
