function run_project(mode)
%RUN_PROJECT  realtime_aruco_pose 唯一入口（RUN.bat 调用它）
%
%   run_project()             自动：相机在线 -> 实时识别；离线 -> 照片演示
%   run_project('realtime')   强制实时识别（离线会明确报错，不降级）
%   run_project('demo')       只跑照片演示，完全不碰相机
%   run_project('check')      只跑 quickstart 自检
%
%   检测与解算全部在 MATLAB 纯 M 代码内完成，不调用 Python / OpenCV / MEX。

    if nargin < 1 || isempty(mode), mode = 'auto'; end
    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    addpath(here);

    fprintf('\n============================================================\n');
    fprintf(' realtime_aruco_pose | MATLAB pure M realtime ArUco pose\n');
    fprintf(' project : %s\n', root);
    fprintf(' mode    : %s\n', mode);
    fprintf('============================================================\n');

    % check 模式由 quickstart 自己打印完整预检，避免重复输出
    if strcmpi(mode, 'check')
        quickstart();
        return;
    end

    P = preflight(true);      % 换电脑后先说清楚缺什么
    switch lower(mode)
        case 'demo'
            run_demo(root, 'manual demo requested');
        case 'realtime'
            start_live(root, true, P);
        otherwise
            start_live(root, false, P);
    end
end

function start_live(root, force, P)
    % 环境不完整时不进相机分支，直接给出可操作的修复清单并降级演示
    if ~P.canRealtime
        fprintf('\n------------------------------------------------------------\n');
        fprintf(' REALTIME PREREQUISITES NOT MET on this machine.\n');
        if ~isempty(P.warnings)
            fprintf(' Missing / needs setup:\n');
            for k = 1:numel(P.warnings)
                fprintf('   - %s\n', P.warnings{k});
            end
        end
        if ~isempty(P.issues)
            fprintf(' Blocking issues:\n');
            for k = 1:numel(P.issues)
                fprintf('   - %s\n', P.issues{k});
            end
        end
        fprintf(' See README section 2 for the install checklist.\n');
        fprintf(' Running PHOTO DEMO instead (no camera / SDK needed).\n');
        fprintf('------------------------------------------------------------\n');
        if force
            error('run_project:notReady', ...
                  '实时模式所需环境不完整，见上方预检报告。');
        end
        run_demo(root, 'realtime prerequisites missing');
        return;
    end

    n = camera_count();       % 轻量枚举：不打开设备、不占相机
    if n > 0
        fprintf('[RUN] CAMERA ONLINE: %d device(s) -> starting realtime loop\n', n);
        fprintf('[RUN] HUD window : MATLAB realtime relative pose (LIVE)\n');
        fprintf('[RUN] Dashboard  : results\\realtime_dashboard.html\n');
        fprintf('[RUN] Press Ctrl-C or close this console to STOP.\n\n');
        start_realtime();     % 无限循环，直到用户停止
    elseif n == 0 && ~force
        fprintf('\n------------------------------------------------------------\n');
        fprintf(' CAMERA OFFLINE - 0 device(s) found.\n');
        fprintf(' This is a USB / hardware issue, NOT a code error.\n');
        fprintf('   1) Replug the camera USB cable\n');
        fprintf('   2) Close GalaxyView and any other capture program\n');
        fprintf('   3) Run RUN.bat again (or RUN.bat check to verify)\n');
        fprintf(' Running PHOTO DEMO now so you can still see the pipeline.\n');
        fprintf('------------------------------------------------------------\n');
        run_demo(root, 'camera offline');
    elseif n == 0
        error('run_project:noCamera', ...
              'CAMERA OFFLINE: 0 devices. Replug USB, close GalaxyView, then run RUN.bat again.');
    else
        fprintf('[RUN] CAMERA UNKNOWN (SDK or loadlibrary not ready) -> photo demo\n');
        run_demo(root, 'camera enumeration unavailable');
    end
end

function run_demo(root, why)
    fprintf('\n[RUN] ---- PHOTO DEMO (no camera needed) ----\n');
    R = struct('ok', false, 'delta_mm', [0 0 0], 'distance_mm', [], ...
               'rotation_deg', [], 'ids', [], 'hamming', []);
    try
        R = aruco_native_pose();
        fprintf('[DEMO] detection ok=%d ids=[%s] hamming=[%s]\n', ...
                R.ok, num2str(R.ids), num2str(R.hamming));
        fprintf('[DEMO] pose dX=%+.1f dY=%+.1f dZ=%+.1f | D=%.1f | rot=%.1f\n', ...
                R.delta_mm(1), R.delta_mm(2), R.delta_mm(3), ...
                R.distance_mm, R.rotation_deg);
    catch e
        fprintf('[DEMO] static solve failed: %s\n', e.message);
    end

    S = struct('frames', 0, 'valid', 0, 'avg_fps', 0);
    try
        S = realtime_pose_matlab('Source','photo','Frames',12, ...
                                 'ShowHUD',false,'Decimate',4);
        fprintf('[DEMO] loop frames=%d valid=%d fps=%.2f\n', ...
                S.frames, S.valid, S.avg_fps);
    catch e
        fprintf('[DEMO] loop failed: %s\n', e.message);
    end

    % 明确标注为 demo 的快照，供看板显示，绝不冒充实时数据
    if R.ok
        d = R.delta_mm;
        s = struct('running', false, 'demo', true, ...
                   'frame', S.frames, 'valid', S.valid, 'fps', S.avg_fps, ...
                   'ok', true, 'dX_mm', d(1), 'dY_mm', d(2), 'dZ_mm', d(3), ...
                   'distance_mm', R.distance_mm, 'rotation_deg', R.rotation_deg, ...
                   'ids', R.ids, 'engine', 'MATLAB pure M PHOTO DEMO (not live)');
    else
        s = struct('running', false, 'demo', true, ...
                   'frame', 0, 'valid', 0, 'fps', 0, ...
                   'ok', false, 'dX_mm', [], 'dY_mm', [], 'dZ_mm', [], ...
                   'distance_mm', [], 'rotation_deg', [], ...
                   'ids', [], 'engine', 'MATLAB pure M PHOTO DEMO (not live)');
    end
    write_live(root, s);      % 同时写 .json 与 .js，file:// 看板也能显示
    out = fullfile(root, 'results', 'realtime_live.json');
    fprintf('[DEMO] wrote %s (demo=true, running=false)\n', out);

    png = fullfile(root, 'results', 'matlab_native_pose.png');
    if exist(png, 'file')
        open_image(png);        % Windows / macOS / Linux 各自的系统打开方式
        fprintf('[DEMO] opened annotated image: %s\n', png);
    end
    fprintf('[DEMO] reason: %s\n', why);
    fprintf('[DEMO] NOT realtime. After replugging USB, run RUN.bat again.\n\n');
end
