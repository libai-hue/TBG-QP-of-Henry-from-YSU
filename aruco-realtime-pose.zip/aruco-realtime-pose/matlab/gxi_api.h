/*
 * gxi_api.h  --  Minimal MATLAB loadlibrary header for Daheng GxIAPI.dll
 *
 * Usage:  loadlibrary('GxIAPI.dll', 'gxi_api.h')
 *
 * Only the functions used by gx_camera.m are declared.  Field order of
 * GX_FRAME_DATA must match the official SDK header exactly, otherwise
 * width / height read back as garbage.
 *
 * 2026-11-06: comments converted to ASCII to avoid MSVC warning C4819
 *             (header contained characters not representable in codepage 936).
 */
#ifndef GXI_API_H
#define GXI_API_H

typedef void * GX_DEVICE_HANDLE;

/* GX_FRAME_DATA (64 bytes on x64) */
typedef struct GX_FRAME_DATA
{
    int                 nStatus;      /* 0 = success */
    void *              pImgBuf;      /* camera internal buffer, do not free */
    int                 nWidth;
    int                 nHeight;
    int                 nPixelFormat;
    int                 nImgSize;
    unsigned long long  nFrameID;
    unsigned long long  nTimeStamp;   /* device timestamp, ns */
    unsigned long long  nBufID;
    int                 nReserved;
} GX_FRAME_DATA, *PGX_FRAME_DATA;

/* GX_INT_RANGE, used to read ROI increment constraints */
typedef struct GX_INT_RANGE
{
    unsigned long long  nMin;
    unsigned long long  nMax;
    unsigned long long  nInc;
    int                 nReserved[8];
} GX_INT_RANGE, *PGX_INT_RANGE;

int GXInitLib(void);
int GXCloseLib(void);

int GXUpdateDeviceList(unsigned int * pNum, unsigned int uiTimeOut);
int GXOpenDeviceByIndex(unsigned int uiIndex, GX_DEVICE_HANDLE * phDevice);
int GXCloseDevice(GX_DEVICE_HANDLE hDevice);

int GXSetEnum(GX_DEVICE_HANDLE hDevice, unsigned int featureID, long long emValue);
int GXGetEnum(GX_DEVICE_HANDLE hDevice, unsigned int featureID, int * pnValue);
int GXSetInt(GX_DEVICE_HANDLE hDevice, unsigned int featureID, long long nValue);
int GXGetInt(GX_DEVICE_HANDLE hDevice, unsigned int featureID, long long * pnValue);
int GXGetIntRange(GX_DEVICE_HANDLE hDevice, unsigned int featureID, PGX_INT_RANGE pIntRange);
int GXSetFloat(GX_DEVICE_HANDLE hDevice, unsigned int featureID, double dValue);
int GXGetFloat(GX_DEVICE_HANDLE hDevice, unsigned int featureID, double * pdValue);
int GXSendCommand(GX_DEVICE_HANDLE hDevice, unsigned int featureID);

int GXGetImage(GX_DEVICE_HANDLE hDevice, PGX_FRAME_DATA pFrameData, unsigned int uiTimeout);

#endif /* GXI_API_H */
