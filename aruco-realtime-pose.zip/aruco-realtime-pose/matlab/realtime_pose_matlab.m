function S = realtime_pose_matlab(varargin)
%REALTIME_POSE_MATLAB  MATLAB 实时计算两标记相对位姿（纯 M，不调用 Python）
%
%   S = realtime_pose_matlab('Frames', 60)              % 实时相机，抓 60 帧
%   S = realtime_pose_matlab('Frames', 30, 'Source','photo')  % 用静态照片跑通链路
%   S = realtime_pose_matlab('Frames', 0)               % 0 = 一直跑，Ctrl-C 停止
%
%   可选参数:
%     'Source'      'camera'(默认) | 'photo'（照片不占相机，用于跑通链路）
%     'Frames'      帧数，默认 60；0 表示无限（Ctrl-C 停止）
%     'ExposureUs'  曝光(us)，默认 50000（当前小光圈实测值）
%     'GainCode'    设备 raw 增益，默认 400（camera 模式）；[] 表示不设置
%     'UseRealK'    true(默认) 用标称相机内参；false 用平面单应性自标定
%     'ShowHUD'     true(默认) 每帧刷新图像与数值；后台运行设 false
%     'Decimate'    HUD 刷新间隔帧数，默认 5（提升环路帧率）
%     'MaxDim'      检测前降采样最大边长，默认 720；0 = 不降采样
%
%   持续运行 + HUD + 每帧写 JSON 请用 start_realtime.m。
%   一键自检（不占相机）请用 quickstart.m。
%
%   每帧都调用 aruco_solve_frame.m —— 检测、解码、PnP、相对位姿
%   全部在 MATLAB 内完成。相机为独占设备，VS 实时程序不能同时运行。

    C = project_config();          % 参数统一来自 config.json（换电脑只改一处）
    p = inputParser;
    p.addParameter('Source',    'camera', @ischar);
    p.addParameter('Frames',    60,       @isnumeric);
    p.addParameter('ExposureUs',C.ExposureUs, @isnumeric);
    p.addParameter('UseRealK',  true,     @islogical);
    p.addParameter('ShowHUD',   true,     @islogical);
    p.addParameter('Decimate',  5,        @isnumeric);
    p.addParameter('MaxDim',    C.MaxDim, @isnumeric);   % 0 = 不降采样
    p.addParameter('GainCode',  [],       @isnumeric);   % 设备 raw gain
    p.parse(varargin{:});
    o = p.Results;
    opts = struct('MaxDim', o.MaxDim, 'TagSizeMM', C.TagSizeMM);

    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    addpath(here);

    % 内参来自 config.json；UseRealK=false 时用平面单应性自标定
    if o.UseRealK
        K = C.K;
    else
        K = [];
    end
    if isempty(o.GainCode) && strcmpi(o.Source, 'camera')
        o.GainCode = C.GainCode;
    end
    gainShow = o.GainCode;
    if isempty(gainShow), gainShow = 0; end
    kShow = 0;
    if ~isempty(K), kShow = K(1,1); end
    fprintf('[RT] source=%s exp=%d gain=%d K=%.1f engine=MATLAB pure M\n', ...
            o.Source, o.ExposureUs, gainShow, kShow);

    cam = [];
    photoFrame = [];
    if strcmpi(o.Source, 'camera')
        cam = gx_camera('ExposureUs', o.ExposureUs);
        fprintf('[RT] camera opened %dx%d\n', cam.Width, cam.Height);
        if ~isempty(o.GainCode)
            % GX_FLOAT_FEATURE_ID_GAIN = 0x20001393；MER 系列为 raw code
            try
                calllib('GxIAPI', 'GXSetFloat', cam.Handle, ...
                        uint32(hex2dec(C.GainFeatureID)), double(o.GainCode));
                fprintf('[RT] gain code set to %d\n', o.GainCode);
            catch ge
                fprintf('[RT] gain set failed: %s\n', ge.message);
            end
        end
        cleanCam = onCleanup(@() delete(cam));
    else
        photoFrame = imread(fullfile(root, 'sample', 'two_markers_photo.jpg'));
        fprintf('[RT] photo frame %dx%d (loop simulation)\n', ...
                size(photoFrame, 2), size(photoFrame, 1));
    end

    maxN = o.Frames;
    if maxN <= 0, maxN = inf; end
    history = struct('t', {}, 'dX', {}, 'dY', {}, 'dZ', {}, ...
                     'D', {}, 'rot', {}, 'fps', {});
    hFig = []; hImg = []; hTxt = []; hAx = []; hMarks = []; hLine = [];
    tic; n = 0; valid = 0; tPrev = toc;

    while n < maxN
        if strcmpi(o.Source, 'camera')
            frame = cam.grab();
        else
            frame = photoFrame;
        end
        n = n + 1;
        R = aruco_solve_frame(frame, K, false, opts);
        tNow = toc;
        fps = 1 / max(tNow - tPrev, 1e-6); tPrev = tNow;

        if R.ok
            valid = valid + 1;
            d = R.delta_mm;
            history(end+1) = struct('t', tNow, 'dX', d(1), 'dY', d(2), ...
                                    'dZ', d(3), 'D', R.distance_mm, ...
                                    'rot', R.rotation_deg, 'fps', fps); %#ok<AGROW>
            if mod(n, max(1, round(o.Decimate))) == 0
                fprintf('[RT] #%4d valid=%4d %5.1f fps | dX=%+7.1f dY=%+7.1f dZ=%+7.1f | D=%6.1f rot=%5.1f\n', ...
                        n, valid, fps, d(1), d(2), d(3), R.distance_mm, R.rotation_deg);
            end
        else
            if mod(n, max(1, round(o.Decimate))) == 0
                fprintf('[RT] #%4d valid=%4d %5.1f fps | no detection\n', n, valid, fps);
            end
        end

        if o.ShowHUD && (isempty(hFig) || ~ishandle(hFig))
            hFig = figure('Name','MATLAB realtime relative pose', ...
                          'NumberTitle','off', 'Position',[60 60 900 700]);
            hAx = axes('Parent', hFig);
            hImg = imshow(frame, 'Parent', hAx);
            hold(hAx, 'on');
            hTxt = text(hAx, 20, 40, '', 'Color','y', 'FontSize',12, ...
                        'FontWeight','bold');
            hMarks = gobjects(1, 2);
            for k = 1:2
                hMarks(k) = plot(hAx, [0 0], [0 0], 'g-', 'LineWidth', 3);
            end
            hLine = plot(hAx, [0 0], [0 0], 'r-', 'LineWidth', 2);
            hold(hAx, 'off');
            drawnow;
        end
        if o.ShowHUD && mod(n, max(1, round(o.Decimate))) == 0 && ishandle(hFig)
            set(hImg, 'CData', frame);
            if R.ok
                for k = 1:2
                    q = R.(sprintf('q%d', k-1)); qc = [q; q(1,:)];
                    set(hMarks(k), 'XData', qc(:,1), 'YData', qc(:,2));
                end
                c0 = mean(R.q0,1); c1 = mean(R.q1,1);
                set(hLine, 'XData', [c0(1) c1(1)], 'YData', [c0(2) c1(2)]);
                s = sprintf('frame %d | %.1f fps | dX %+.1f dY %+.1f dZ %+.1f mm | D %.1f | rot %.1f', ...
                            n, fps, d(1), d(2), d(3), R.distance_mm, R.rotation_deg);
            else
                for k = 1:2, set(hMarks(k), 'XData', [0 0], 'YData', [0 0]); end
                set(hLine, 'XData', [0 0], 'YData', [0 0]);
                s = sprintf('frame %d | %.1f fps | no detection - place both markers in view', n, fps);
            end
            set(hTxt, 'String', s);
            title(hAx, s, 'FontSize', 11);
            drawnow limitrate;
        end
    end

    elapsed = toc;
    S = struct('frames', n, 'valid', valid, 'elapsed_s', elapsed, ...
               'avg_fps', n / max(elapsed, 1e-6), 'history', history, ...
               'engine', 'MATLAB pure M realtime loop');
    fprintf('[RT] done: %d frames, %d valid, %.2f s, %.2f fps avg\n', ...
            n, valid, elapsed, S.avg_fps);
    outjson = fullfile(root, 'results', 'realtime_matlab_result.json');
    fid = fopen(outjson, 'w'); fwrite(fid, jsonencode(S), 'char'); fclose(fid);
    fprintf('[RT] saved %s\n', outjson);
end
