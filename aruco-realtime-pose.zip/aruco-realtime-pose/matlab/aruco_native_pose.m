function R = aruco_native_pose(photoPath, K)
%ARUCO_NATIVE_POSE  静态入口：把一张照片当作相机帧，纯 MATLAB 解算并画图
%
%   R = aruco_native_pose();                 % 默认 sample/two_markers_photo.jpg
%   R = aruco_native_pose(path)             % 指定图片
%   R = aruco_native_pose(path, K)          % 给定内参（实时相机标定值）
%
%   检测与解算全部由 aruco_solve_frame.m 在 MATLAB 内完成；本函数只负责
%   读图、画图、落盘。运行时不调用 Python / OpenCV / MEX。
%   实时循环请直接用 realtime_pose_matlab.m（复用同一个 solveFrame）。

    if nargin < 1 || isempty(photoPath)
        here = fileparts(mfilename('fullpath'));
        root = fileparts(here);
        photoPath = fullfile(root, 'sample', 'two_markers_photo.jpg');
    end
    if nargin < 2, K = []; end
    if ~exist(photoPath, 'file')
        error('aruco_native_pose:noPhoto', '找不到 %s', photoPath);
    end

    img = imread(photoPath);
    R = aruco_solve_frame(img, K, true);
    if ~R.ok
        error('aruco_native_pose:notFound', '未同时检出 ID 0/1');
    end

    delta = R.delta_mm; distmm = R.distance_mm; angle = R.rotation_deg;
    fprintf('[MATLAB] B-A: dX=%+.1f dY=%+.1f dZ=%+.1f mm | D=%.1f mm | rot=%.1f deg\n', ...
            delta(1), delta(2), delta(3), distmm, angle);
    fprintf('[MATLAB] engine: %s\n', R.engine);

    fig = figure('Name', 'MATLAB native ArUco detection | relative pose', ...
                 'NumberTitle', 'off', 'Position', [60 60 980 1180]);
    imshow(img); hold on;
    title(sprintf('MATLAB native | dX=%+.1f dY=%+.1f dZ=%+.1f mm | D=%.1f mm | rot=%.1f deg', ...
                  delta(1), delta(2), delta(3), distmm, angle), 'FontSize', 12);
    quads = {R.q0, R.q1};
    centers = zeros(2, 2);
    for k = 1:2
        q = quads{k}; qc = [q; q(1, :)];
        plot(qc(:, 1), qc(:, 2), '-', 'LineWidth', 3, 'Color', [0.1 0.85 0.25]);
        c = mean(q, 1); centers(k, :) = c;
        plot(c(1), c(2), 'o', 'MarkerSize', 14, ...
             'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'w');
        text(c(1)-40, c(2)-70, sprintf('ID %d', R.ids(k)), ...
             'Color', 'y', 'FontSize', 16, 'FontWeight', 'bold');
    end
    plot(centers(:, 1), centers(:, 2), 'r-', 'LineWidth', 3);
    text(40, 150, sprintf('B - A: dX %+.1f  dY %+.1f  dZ %+.1f mm', ...
         delta(1), delta(2), delta(3)), 'Color', 'y', 'FontSize', 14, 'FontWeight', 'bold');
    text(40, 200, sprintf('distance %.1f mm   rotation %.1f deg', distmm, angle), ...
         'Color', 'y', 'FontSize', 14, 'FontWeight', 'bold');
    text(40, 250, 'computed entirely inside MATLAB (no Python / OpenCV)', ...
         'Color', 'y', 'FontSize', 11);
    hold off; drawnow;

    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    outpng = fullfile(root, 'results', 'matlab_native_pose.png');
    save_figure(fig, outpng);
    outjson = fullfile(root, 'results', 'matlab_native_result.json');
    fid = fopen(outjson, 'w'); fwrite(fid, jsonencode(R), 'char'); fclose(fid);
    fprintf('[MATLAB] saved %s\n[MATLAB] saved %s\n', outpng, outjson);
end

function save_figure(fig, path)
%SAVE_FIGURE  保存标注图；主文件被图片查看器锁定时不中断解算、不产生警告
%   先写唯一临时 PNG，再原子替换；失败则保留为带时间戳的备用文件。
    [p, n, e] = fileparts(path);
    tmp = fullfile(p, [n '_tmp_' datestr(now, 'HHMMSSFFF') e]);
    ok = false;
    try
        saveas(fig, tmp);
        [ok, ~] = movefile(tmp, path, 'f');   % 双输出形式：失败只返回 false，不发警告
    catch
        ok = false;
    end
    if ok
        return;
    end

    alt = fullfile(p, [n '_' datestr(now, 'yyyymmdd_HHMMSS') e]);
    try
        if exist(tmp, 'file')
            [ok2, ~] = movefile(tmp, alt, 'f');
            if ~ok2
                saveas(fig, alt);
            end
        else
            saveas(fig, alt);
        end
        fprintf('[MATLAB] primary PNG locked; saved to %s instead\n', alt);
    catch e2
        fprintf('[MATLAB] warning: could not save PNG (%s)\n', e2.message);
    end
end
