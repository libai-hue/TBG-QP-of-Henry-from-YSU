function cam_probe()
%CAM_PROBE  抓一帧真实相机，检查两枚标记是否在视野内
%   会独占相机约 1 秒；实时循环运行时不要调用。
    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    addpath(here);
    C = project_config();
    c = gx_camera('ExposureUs', C.ExposureUs);
    calllib('GxIAPI', 'GXSetFloat', c.Handle, ...
            uint32(hex2dec(C.GainFeatureID)), double(C.GainCode));
    for k = 1:5, f = c.grab(); end     % 丢弃前几帧，等曝光/增益生效
    delete(c);
    fprintf('[cam_probe] frame %d x %d, mean %.1f\n', ...
            size(f, 2), size(f, 1), mean(double(f(:))));
    R = aruco_solve_frame(f, C.K, true, ...
                          struct('MaxDim', C.MaxDim, 'TagSizeMM', C.TagSizeMM));
    fprintf('[cam_probe] detect ok = %d\n', R.ok);
    if R.ok
        fprintf('[cam_probe] pose dX=%.1f dY=%.1f dZ=%.1f D=%.1f rot=%.1f\n', ...
                R.delta_mm(1), R.delta_mm(2), R.delta_mm(3), ...
                R.distance_mm, R.rotation_deg);
    end
    imwrite(f, fullfile(root, 'results', 'cam_probe.png'));
    fprintf('[cam_probe] saved results/cam_probe.png\n');
end
