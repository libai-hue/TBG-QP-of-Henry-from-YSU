function S = galaxy_sdk_root()
%GALAXY_SDK_ROOT  自动定位 GxIAPI.dll，供所有脚本共用（不再各自硬编码路径）
%
%   S.found   是否找到
%   S.dll     GxIAPI.dll 完整路径（未找到时为 ''）
%   S.dir     DLL 所在目录（未找到时为 ''）
%   S.header  项目内 gxi_api.h 路径
%   S.source  命中来源说明
%
%   查找顺序：
%     1) 环境变量 ARUCO_SDK_ROOT / GALAXYSDK_ROOT（可指向 SDK 根或 DLL 目录）
%     2) config.json 的 sdk.root
%     3) 项目内 sdk/Win64/（把 DLL 放进项目即可完全便携）
%     4) 常见安装目录
%     5) 系统 PATH 中的各个目录
%
%   只有「实时相机」模式需要找到它；照片演示模式完全不需要 SDK。

    C = project_config();
    S = struct('found', false, 'dll', '', 'dir', '', ...
               'header', C.HeaderFile, 'source', 'none');
    root = C.Root;

    cands = {};
    roots = {};
    for v = {'ARUCO_SDK_ROOT', 'GALAXYSDK_ROOT'}
        val = getenv(v{1});
        if ~isempty(val), roots{end+1} = val; end %#ok<AGROW>
    end
    if ~isempty(C.SdkRoot), roots{end+1} = C.SdkRoot; end
    for r = roots
        d = r{1};
        cands{end+1} = fullfile(d, 'GxIAPI.dll');                    %#ok<AGROW>
        cands{end+1} = fullfile(d, 'APIDll', 'Win64', 'GxIAPI.dll'); %#ok<AGROW>
        cands{end+1} = fullfile(d, 'Win64', 'GxIAPI.dll');           %#ok<AGROW>
    end

    % 项目内携带 DLL：整体拷贝文件夹即可带着 SDK 走
    cands{end+1} = fullfile(root, 'sdk', 'Win64', 'GxIAPI.dll');
    cands{end+1} = fullfile(root, 'sdk', 'GxIAPI.dll');

    common = { ...
        'D:\GalaxySDK\APIDll\Win64\GxIAPI.dll', ...
        'C:\GalaxySDK\APIDll\Win64\GxIAPI.dll', ...
        'C:\Program Files\Daheng Imaging\GalaxySDK\APIDll\Win64\GxIAPI.dll', ...
        'C:\Program Files (x86)\Daheng Imaging\GalaxySDK\APIDll\Win64\GxIAPI.dll', ...
        'C:\Program Files\GalaxySDK\APIDll\Win64\GxIAPI.dll', ...
        'D:\Program Files\Daheng\GalaxySDK\APIDll\Win64\GxIAPI.dll'};
    cands = [cands, common];

    pp = strsplit(getenv('PATH'), pathsep);
    for k = 1:numel(pp)
        if ~isempty(pp{k})
            cands{end+1} = fullfile(pp{k}, 'GxIAPI.dll'); %#ok<AGROW>
        end
    end

    for k = 1:numel(cands)
        if exist(cands{k}, 'file') == 2
            S.found  = true;
            S.dll    = cands{k};
            S.dir    = fileparts(cands{k});
            S.source = cands{k};
            return;
        end
    end
end
