function open_image(path)
%OPEN_IMAGE  跨平台打开标注图，且不锁定主产物文件
%
%   Windows 的图片查看器会锁住被打开的 PNG，导致下一次 saveas 覆盖失败
%   （"PNG 库失败: Could not open file"）。因此先复制成 *_preview.png 再打开。
%   任何失败都静默跳过，不影响识别与解算主流程。

    if ~exist(path, 'file'), return; end
    try
        [p, n, e] = fileparts(path);
        prev = fullfile(p, [n '_preview' e]);
        try
            copyfile(path, prev, 'f');
        catch
            prev = path;         % 复制失败就退回到直接打开原文件
        end
        if ispc
            winopen(prev);
        elseif ismac
            system(['open "' prev '"']);
        else
            system(['xdg-open "' prev '"']);
        end
    catch
    end
end
