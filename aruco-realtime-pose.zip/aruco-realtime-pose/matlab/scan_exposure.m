function scan_exposure()
%SCAN_EXPOSURE  扫描当前光圈下的曝光 x 增益，找适合 ArUco 检测的亮度
    addpath(fileparts(mfilename('fullpath')));
    exps  = [15000, 30000, 50000];
    gains = [0, 200, 400, 600];
    GAIN_FID = uint32(hex2dec('20001393'));
    for g = gains
        for e = exps
            c = [];
            try
                c = gx_camera('ExposureUs', e);
                calllib('GxIAPI', 'GXSetFloat', c.Handle, GAIN_FID, double(g));
                for k = 1:4, f = c.grab(); end
                delete(c); c = [];
                fprintf('[scan] exp=%5d gain=%3d  mean=%6.1f  std=%5.1f  sat=%5.1f%%\n', ...
                        e, g, mean(double(f(:))), std(double(f(:))), ...
                        100 * mean(f(:) >= 250));
            catch err
                if ~isempty(c), try, delete(c); catch, end; end
                fprintf('[scan] exp=%5d gain=%3d ERR %s\n', e, g, err.message);
            end
        end
    end
end
