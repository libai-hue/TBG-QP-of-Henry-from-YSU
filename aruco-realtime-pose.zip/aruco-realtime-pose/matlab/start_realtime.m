function start_realtime()
%START_REALTIME  启动持续运行的实时相对位置识别（MATLAB 纯 M）
%
%   在 MATLAB 命令窗口敲  start_realtime  即开始；Ctrl-C 停止。
%   每帧把最新结果写入 results/realtime_live.json 与 .js，供外部/看板读取。
%   推荐使用项目根的 RUN.bat 启动（会自动检查相机并打开看板）。
%   HUD figure 实时显示相机画面、检测框、连线与 dX/dY/dZ、距离、转角。

    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    addpath(here);
    C = project_config();
    K = C.K;

    fprintf('[LIVE] starting MATLAB realtime pose (Ctrl-C to stop)\n');
    fprintf('[LIVE] config: exp=%dus gain=%d K.fx=%.1f tag=%.1fmm maxdim=%d\n', ...
            C.ExposureUs, C.GainCode, K(1,1), C.TagSizeMM, C.MaxDim);

    cam = gx_camera('ExposureUs', C.ExposureUs);
    calllib('GxIAPI', 'GXSetFloat', cam.Handle, ...
            uint32(hex2dec(C.GainFeatureID)), double(C.GainCode));
    fprintf('[LIVE] camera %dx%d opened\n', cam.Width, cam.Height);
    finish = onCleanup(@() mark_stopped(root));   % 退出时把看板标为未运行
    c = onCleanup(@() delete(cam));

    opts = struct('MaxDim', C.MaxDim, 'TagSizeMM', C.TagSizeMM);
    hFig = []; hImg = []; hTxt = []; hAx = []; hMarks = []; hLine = [];
    n = 0; valid = 0; tPrev = tic; nFail = 0;

    while true
        % USB 瞬时取帧错误不应让整个循环退出：连续 5 次失败才判定掉线
        try
            frame = cam.grab();
            nFail = 0;
        catch ge
            nFail = nFail + 1;
            fprintf('[LIVE] grab failed (%d/5): %s\n', nFail, ge.message);
            if nFail >= 5
                fprintf('[LIVE] camera link lost. Replug USB, then run RUN.bat again.\n');
                break;
            end
            pause(0.05);
            continue;
        end
        n = n + 1;
        R = aruco_solve_frame(frame, K, false, opts);
        tNow = toc; fps = 1 / max(tNow - tPrev, 1e-6); tPrev = tNow;
        if R.ok, valid = valid + 1; d = R.delta_mm; end

        % 每帧写 JSON（原子替换），外部可实时读
        if R.ok
            s = struct('running', true, 'demo', false, 'frame', n, 'valid', valid, ...
                       'fps', fps, 'ok', true, ...
                       'dX_mm', d(1), 'dY_mm', d(2), 'dZ_mm', d(3), ...
                       'distance_mm', R.distance_mm, 'rotation_deg', R.rotation_deg, ...
                       'ids', R.ids, 'engine', 'MATLAB pure M realtime');
            msg = sprintf('frame %d | %.1f fps | dX %+.1f dY %+.1f dZ %+.1f | D %.1f | rot %.1f', ...
                          n, fps, d(1), d(2), d(3), R.distance_mm, R.rotation_deg);
        else
            s = struct('running', true, 'demo', false, 'frame', n, 'valid', valid, ...
                       'fps', fps, 'ok', false, ...
                       'dX_mm', [], 'dY_mm', [], 'dZ_mm', [], ...
                       'distance_mm', [], 'rotation_deg', [], ...
                       'ids', [], 'engine', 'MATLAB pure M realtime');
            msg = sprintf('frame %d | %.1f fps | no detection - place both markers in view', n, fps);
        end
        % 每帧同时写 .json 与 .js（原子替换），外部/看板可实时读
        write_live(root, s);

        if mod(n, 5) == 0
            fprintf('[LIVE] %s\n', msg);
        end

        % HUD
        if isempty(hFig) || ~ishandle(hFig)
            hFig = figure('Name','MATLAB realtime relative pose (LIVE)', ...
                          'NumberTitle','off','Position',[60 60 900 700]);
            hAx = axes('Parent', hFig);
            hImg = imshow(frame, 'Parent', hAx);
            hold(hAx,'on');
            hTxt = text(hAx, 20, 40, '', 'Color','y','FontSize',12,'FontWeight','bold');
            hMarks = gobjects(1,2);
            for k=1:2, hMarks(k)=plot(hAx,[0 0],[0 0],'g-','LineWidth',3); end
            hLine = plot(hAx,[0 0],[0 0],'r-','LineWidth',2);
            hold(hAx,'off'); drawnow;
        end
        if ishandle(hFig)
            set(hImg,'CData',frame);
            if R.ok
                for k=1:2
                    q = R.(sprintf('q%d',k-1)); qc=[q; q(1,:)];
                    set(hMarks(k),'XData',qc(:,1),'YData',qc(:,2));
                end
                c0=mean(R.q0,1); c1=mean(R.q1,1);
                set(hLine,'XData',[c0(1) c1(1)],'YData',[c0(2) c1(2)]);
            else
                for k=1:2, set(hMarks(k),'XData',[0 0],'YData',[0 0]); end
                set(hLine,'XData',[0 0],'YData',[0 0]);
            end
            set(hTxt,'String',msg); title(hAx,msg,'FontSize',11);
            drawnow limitrate;
        end
    end
end

function mark_stopped(root)
% 循环结束（Ctrl-C / 掉线 / 出错）时把数据标为未运行，避免看板显示陈旧数值
    try
        s = struct('running', false, 'demo', false, ...
                   'frame', 0, 'valid', 0, 'fps', 0, 'ok', false, ...
                   'dX_mm', [], 'dY_mm', [], 'dZ_mm', [], ...
                   'distance_mm', [], 'rotation_deg', [], 'ids', [], ...
                   'engine', 'MATLAB pure M realtime (stopped)');
        write_live(root, s);
        fprintf('[LIVE] stopped; dashboard marked as not running.\n');
    catch
    end
end
