function write_live(root, s)
%WRITE_LIVE  原子写 results/realtime_live.json 与 realtime_live.js
%
%   .json 供 HTTP 打开的看板用 fetch 读取；
%   .js   供 file:// 双击打开的看板用 <script> 读取（浏览器会拦截 file:// 的 fetch）。
%   两者内容完全相同，均由 MATLAB 每帧生成，不依赖任何本地服务器。

    res = fullfile(root, 'results');
    if ~exist(res, 'dir'), mkdir(res); end

    % 把当前生效的配置一起写进数据，看板就不会显示另一台机器的旧参数。
    % persistent 缓存：实时循环每帧调用，不必反复读 config.json。
    persistent cfgCache
    if isempty(cfgCache)
        C = project_config();
        cfgCache = struct('fx', C.K(1,1), ...
                          'exposure_us', C.ExposureUs, ...
                          'gain', C.GainCode, ...
                          'tag_mm', C.TagSizeMM, ...
                          'max_dim', C.MaxDim);
    end
    s.cfg = cfgCache;
    txt = jsonencode(s);

    jf = fullfile(res, 'realtime_live.json');
    tmp = [jf '.tmp'];
    fid = fopen(tmp, 'w');
    if fid > 0, fwrite(fid, txt, 'char'); fclose(fid); end
    try
        movefile(tmp, jf, 'f');
    catch
    end

    js = ['window.LIVE = ' txt ';'];
    sf = fullfile(res, 'realtime_live.js');
    tmp2 = [sf '.tmp'];
    fid = fopen(tmp2, 'w');
    if fid > 0, fwrite(fid, js, 'char'); fclose(fid); end
    try
        movefile(tmp2, sf, 'f');
    catch
    end
end
