function run_mac(mode, imagePath)
%RUN_MAC  macOS / Linux 入口：跑纯 MATLAB 的标记检测与相对位姿解算
%
%   run_mac()                      照片演示（默认，不需要相机或 SDK）
%   run_mac('check')               环境预检 + 自检
%   run_mac('image', '/path/x.jpg') 对指定图片做一次解算、画图、落盘
%
%   实时相机采集在 macOS 上暂不支持：gx_camera.m 依赖 Windows 的
%   GxIAPI.dll 与 loadlibrary thunk。大恒官方提供 macOS 版 Galaxy SDK，
%   若要接相机，需把相机驱动移植到该 SDK（检测/解算核心无需改动）。
%
%   本入口及其调用的核心全部是纯 M 代码，只依赖 Image Processing Toolbox。

    if nargin < 1 || isempty(mode), mode = 'demo'; end
    if nargin < 2, imagePath = ''; end
    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    addpath(here);

    fprintf('\n============================================================\n');
    fprintf(' realtime_aruco_pose | macOS / Linux entry\n');
    fprintf(' platform : %s\n', computer('arch'));
    fprintf(' folder   : %s\n', root);
    fprintf('============================================================\n');
    if ispc
        fprintf('[note] Windows detected - RUN.bat is the recommended entry.\n');
    end

    switch lower(mode)
        case 'check'
            quickstart();
        case 'image'
            if isempty(imagePath) || exist(imagePath, 'file') ~= 2
                error('run_mac:noImage', 'Image not found: %s', imagePath);
            end
            C = project_config();
            R = aruco_native_pose(imagePath, C.K);
            if R.ok
                d = R.delta_mm;
                fprintf('[MAC] ok=%d dX=%+.1f dY=%+.1f dZ=%+.1f | D=%.1f | rot=%.1f\n', ...
                        R.ok, d(1), d(2), d(3), R.distance_mm, R.rotation_deg);
            else
                fprintf('[MAC] no detection in %s\n', imagePath);
            end
            png = fullfile(root, 'results', 'matlab_native_pose.png');
            open_image(png);
        otherwise
            run_project('demo');   % 复用已验证链路：预检 + 解算 + 循环 + 写看板数据
    end

    fprintf('[MAC] dashboard: %s\n', ...
            fullfile(root, 'results', 'realtime_dashboard.html'));
    fprintf('[MAC] note: live camera capture is Windows-only in this build.\n\n');
end
