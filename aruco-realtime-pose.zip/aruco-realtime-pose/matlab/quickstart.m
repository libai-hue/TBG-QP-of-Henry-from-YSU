function quickstart()
%QUICKSTART  一条命令跑通本项目（不占相机，随时可执行）
%
%   在 MATLAB 命令窗口:
%       cd('...\realtime_aruco_pose\matlab')
%       quickstart
%
%   依次完成：
%     1) 环境自检（工具箱、核心文件、SDK DLL）
%     2) 示例照片静态解算 aruco_native_pose（弹 figure + 落盘）
%     3) 照片模式实时循环 realtime_pose_matlab（验证逐帧链路）
%     4) 相机在线枚举（只枚举、不打开设备、不占相机）
%     5) 打印下一步该敲什么
%
%   相机在线后在同一个窗口敲  start_realtime  才是真正的实时识别。

    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);
    addpath(here);

    fprintf('\n================ realtime_aruco_pose quickstart ================\n');
    fprintf('project root : %s\n', root);
    fprintf('MATLAB       : %s\n', version);

    %% ---------- 1. 环境自检（跨电脑可移植） ----------
    fprintf('\n--- [1/4] 环境自检 ---\n');
    P = preflight(true);
    needFile = {'aruco_solve_frame.m', 'aruco_dict_4x4_50.m', ...
                'realtime_pose_matlab.m', 'start_realtime.m', ...
                'gx_camera.m', 'gxi_api.h', 'project_config.m', ...
                'galaxy_sdk_root.m', 'preflight.m', 'write_live.m'};
    for k = 1:numel(needFile)
        if exist(fullfile(here, needFile{k}), 'file')
            fprintf('  OK   %s\n', needFile{k});
        else
            fprintf('  MISS %s\n', needFile{k});
        end
    end
    if ~P.ok
        fprintf('  [WARN] 基础环境不完整，按上面 FAIL 提示修复后再运行。\n');
    end

    %% ---------- 2. 静态解算（照片当一帧） ----------
    fprintf('\n--- [2/4] 静态解算：sample/two_markers_photo.jpg ---\n');
    try
        R = aruco_native_pose();
        fprintf('  RESULT ok=%d  ids=[%s]  hamming=[%s]\n', ...
                R.ok, num2str(R.ids), num2str(R.hamming));
        fprintf('  RESULT dX=%+.1f dY=%+.1f dZ=%+.1f mm | D=%.1f mm | rot=%.1f deg\n', ...
                R.delta_mm(1), R.delta_mm(2), R.delta_mm(3), ...
                R.distance_mm, R.rotation_deg);
        fprintf('  figure 已弹出；结果已写入 results/\n');
    catch e
        fprintf('  FAILED: %s\n', e.message);
    end

    %% ---------- 3. 照片模式实时循环 ----------
    fprintf('\n--- [3/4] 照片模式实时循环（8 帧，不占相机） ---\n');
    try
        S = realtime_pose_matlab('Source','photo','Frames',8, ...
                                 'ShowHUD',false,'Decimate',4);
        fprintf('  RESULT frames=%d valid=%d avg_fps=%.2f\n', ...
                S.frames, S.valid, S.avg_fps);
    catch e
        fprintf('  FAILED: %s\n', e.message);
    end

    %% ---------- 4. 相机在线检查 ----------
    fprintf('\n--- [4/4] 相机在线检查（只枚举，不打开设备） ---\n');
    n = camera_count();
    if n > 0
        fprintf('  CAMERA ONLINE: %d 台设备\n', n);
        fprintf('  >>> 下一步：双击项目根的 RUN.bat（或敲 start_realtime）\n');
        fprintf('  >>> 然后用浏览器打开 results\\realtime_dashboard.html 看实时数值\n');
    elseif n == 0
        fprintf('  CAMERA OFFLINE: 枚举到 0 台设备\n');
        fprintf('  >>> 重新插拔相机 USB 线；并确认 GalaxyView / 其它采集程序已关闭\n');
        fprintf('  >>> 恢复后双击项目根的 RUN.bat（它会自动进入实时识别）\n');
    else
        fprintf('  CAMERA UNKNOWN: 无法完成枚举（SDK 未装或 loadlibrary 未配置）\n');
        fprintf('  >>> 先在 MATLAB 执行  mex -setup C++  选 VS2022，再重跑 quickstart\n');
    end

    fprintf('\n  注：上面第 2 步用自标定焦距(f=1728)，第 3 步用真实内参 K，\n');
    fprintf('      所以两张照片的数值不同属正常；照片只用于验证链路，不作测量结果。\n');
    fprintf('\n---------------- 常用命令 ----------------\n');
    fprintf('  RUN.bat (双击)                             一键启动：自动判相机/实时/演示\n');
    fprintf('  run_project(''check'') / (''demo'')          统一入口的自检 / 演示模式\n');
    fprintf('  quickstart                                 本自检（不占相机）\n');
    fprintf('  camera_count()                             只枚举相机，不打开设备\n');
    fprintf('  aruco_native_pose()                        单张照片解算 + 画图\n');
    fprintf('  K=[2133.3 0 646; 0 2133.3 482; 0 0 1];    相机内参\n');
    fprintf('  I=imread(''..\\sample\\two_markers_photo.jpg'');\n');
    fprintf('  R=aruco_solve_frame(I, K, true)            任意一帧解算\n');
    fprintf('  cam_probe                                  抓一帧检查视野/曝光\n');
    fprintf('  scan_exposure                              扫描曝光 x 增益\n');
    fprintf('  start_realtime                             持续实时识别（占相机，Ctrl-C 停止）\n');
    fprintf('  S=realtime_pose_matlab(''Frames'',100)       实时相机跑 100 帧并返回统计\n');
    fprintf('================================================================\n\n');
end
