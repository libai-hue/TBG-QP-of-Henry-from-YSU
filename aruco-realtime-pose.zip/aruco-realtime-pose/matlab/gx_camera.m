classdef gx_camera < handle
%GX_CAMERA  大恒 Galaxy 相机（水星/MER 系列）MATLAB 原生采集类
%
%   直接用 loadlibrary 调 GxIAPI.dll，不经过 Python，单帧开销约 1~3 ms。
%
%   用法：
%       cam = gx_camera();                 % 打开第 1 台，默认 6000us 曝光
%       img = cam.grab();                  % 抓 1 帧 uint8 [H x W]
%       [frames, meta] = cam.grab_n(100);  % 连抓 100 帧
%       delete(cam);                       % 关闭并释放
%
%   可选参数（Name-Value）：
%       'Index'      设备序号，默认 1
%       'ExposureUs' 曝光时间(us)，默认 6000
%       'Roi'        [w h] 硬件 ROI，默认 [] 表示全幅
%       'AutoOpen'   是否构造时立即打开，默认 true
%
%   注意：同一台相机同时只能被一个进程占用。
%         若 GalaxyView / Python 脚本还开着，会报 GX_STATUS_INVALID_ACCESS(-8)。
%
%   2026-11-06 实测修正（GalaxySDK 1.6.2001 / MATLAB R2023b）：
%     * loadlibrary 生成的结构体类型名/字段名必须与 gxi_api.h 完全一致；
%     * GXGetImage 要求调用方预分配 pImgBuf 缓冲区，否则返回
%       -5 GX_STATUS_INVALID_PARAMETER（此前误当成「句柄无效」）。

    properties (SetAccess = private)
        Handle      = []      % 设备句柄 (libpointer voidPtr)
        Width       = 0
        Height      = 0
        ExposureUs  = 0
        PixelFormat = 0
        NumDevices  = 0
    end

    properties (Access = private)
        Tic           % 计时起点，用于给每帧打主机时间戳
        ImgBuf = []   % 调用方预分配的图像缓冲 (libpointer uint8Ptr)
        BufSize = 0
    end

    properties (Constant, Hidden)
        LIB = 'GxIAPI';

        % ---- 功能码 GX_FEATURE_ID_CMD --------------------------------------
        FID = struct( ...
            'Width',                    hex2dec('100003EE'), ...
            'Height',                   hex2dec('100003EF'), ...
            'PixelFormat',              hex2dec('300003F6'), ...
            'AcquisitionMode',          hex2dec('30000BB8'), ...
            'AcquisitionStart',         hex2dec('70000BB9'), ...
            'AcquisitionStop',          hex2dec('70000BBA'), ...
            'ExposureTime',             hex2dec('20000BC1'), ...
            'ExposureAuto',             hex2dec('30000BC2'), ...
            'GainAuto',                 hex2dec('30001388'), ...
            'Gain',                     hex2dec('20001393'), ...
            'AcquisitionFrameRateMode', hex2dec('30000BCE'), ...
            'AcquisitionFrameRate',     hex2dec('20000BCF'));

        % ---- 枚举值 ---------------------------------------------------------
        PIXEL_FORMAT_MONO8      = hex2dec('01080001');
        ACQ_MODE_CONTINUOUS     = 2;
        AUTO_OFF                = 0;
    end

    methods
        % ===================== 构造 / 打开 ==================================
        function obj = gx_camera(varargin)
            p = inputParser;
            p.addParameter('Index',      1,   @(x)isnumeric(x) && isscalar(x));
            p.addParameter('ExposureUs', 6000,@(x)isnumeric(x) && isscalar(x));
            p.addParameter('Roi',        [],  @(x)isempty(x) || numel(x) == 2);
            p.addParameter('AutoOpen',   true,@islogical);
            p.parse(varargin{:});
            o = p.Results;

            if o.AutoOpen
                obj.open(o.Index);
                obj.configure('ExposureUs', o.ExposureUs, 'Roi', o.Roi);
            end
        end

        % ------------------------------------------------------------------
        function open(obj, index)
            if nargin < 2, index = 1; end

            if ~libisloaded(obj.LIB)
                dll = obj.find_dll();
                hdr = fullfile(fileparts(mfilename('fullpath')), 'gxi_api.h');
                % 首次运行若弹出“选择 C 编译器”，选 VS2022 即可；
                % 也可先在命令行执行 mex -setup C++ 预先配好。
                loadlibrary(dll, hdr, 'alias', obj.LIB);
            end

            obj.check(calllib(obj.LIB, 'GXInitLib'), 'GXInitLib');

            nPtr = libpointer('uint32Ptr', 0);
            obj.check(calllib(obj.LIB, 'GXUpdateDeviceList', nPtr, uint32(1000)), ...
                      'GXUpdateDeviceList');
            obj.NumDevices = double(nPtr.Value);

            if obj.NumDevices < 1
                error('gx_camera:noDevice', ...
                      '没有找到相机。检查：USB 线是否插好 / 是否被 GalaxyView 或其它程序占用。');
            end
            if index > obj.NumDevices
                error('gx_camera:badIndex', '只有 %d 台相机，无法打开第 %d 台。', ...
                      obj.NumDevices, index);
            end

            hPtr = libpointer('voidPtrPtr');
            obj.check(calllib(obj.LIB, 'GXOpenDeviceByIndex', uint32(index), hPtr), ...
                      'GXOpenDeviceByIndex');
            obj.Handle = hPtr.Value;
        end

        % ===================== 参数配置 =====================================
        function configure(obj, varargin)
            p = inputParser;
            p.addParameter('ExposureUs', [], @(x)isempty(x) || isnumeric(x));
            p.addParameter('Roi',        [], @(x)isempty(x) || numel(x) == 2);
            p.parse(varargin{:});
            o = p.Results;

            % 像素格式要在 ROI 之前设，改格式会把 ROI 复位
            obj.set_enum(obj.FID.PixelFormat, obj.PIXEL_FORMAT_MONO8, false);

            if ~isempty(o.Roi)
                obj.apply_roi(o.Roi(1), o.Roi(2));
            end

            obj.set_enum(obj.FID.AcquisitionMode, obj.ACQ_MODE_CONTINUOUS, true);
            obj.set_enum(obj.FID.ExposureAuto,    obj.AUTO_OFF,            false);
            obj.set_enum(obj.FID.GainAuto,        obj.AUTO_OFF,            false);
            obj.set_enum(obj.FID.AcquisitionFrameRateMode, obj.AUTO_OFF,   false);

            if ~isempty(o.ExposureUs)
                obj.set_float(obj.FID.ExposureTime, o.ExposureUs, true);
            end

            % 回读实际生效值
            obj.Width       = double(obj.get_int(obj.FID.Width));
            obj.Height      = double(obj.get_int(obj.FID.Height));
            obj.ExposureUs  = obj.get_float(obj.FID.ExposureTime);
            obj.PixelFormat = double(obj.get_enum(obj.FID.PixelFormat));

            % GXGetImage 需要调用方提供 pImgBuf；官方 VC 示例里是
            %   m_stFrameData.pImgBuf = new BYTE[payloadSize];
            % 传 NULL 会返回 -5 GX_STATUS_INVALID_PARAMETER。
            % Mono8 每像素 1 字节，缓冲按当前 Width/Height 分配。
            obj.BufSize = double(obj.Width) * double(obj.Height);
            obj.ImgBuf  = libpointer('uint8Ptr', zeros(obj.BufSize, 1, 'uint8'));

            % 开启采集（连续模式：开一次，后面一直取）
            obj.check(calllib(obj.LIB, 'GXSendCommand', obj.Handle, ...
                              uint32(obj.FID.AcquisitionStart)), 'AcquisitionStart');
            obj.Tic = tic;
        end

        % ===================== 取图 =========================================
        function img = grab(obj, timeoutMs)
        %GRAB  取 1 帧，返回 uint8 [H x W]
            if nargin < 2, timeoutMs = 1000; end
            [img, ~] = obj.grab_one(timeoutMs);
        end

        function [frames, meta] = grab_n(obj, n, timeoutMs)
        %GRAB_N  连续取 n 帧
        %   frames : uint8 [H x W x n]
        %   meta   : 结构体数组，含 frame_id / timestamp / host_time
            if nargin < 3, timeoutMs = 1000; end
            frames = zeros(obj.Height, obj.Width, n, 'uint8');
            meta   = repmat(struct('frame_id', 0, 'timestamp', 0, 'host_time', 0), 1, n);
            for k = 1:n
                [frames(:,:,k), m] = obj.grab_one(timeoutMs);
                meta(k) = m;
            end
        end

        function [img, m] = grab_one(obj, timeoutMs)
            % 2026-11-06 实测修正：loadlibrary 生成的结构体类型名与字段名
            % 必须与 gxi_api.h 完全一致（GX_FRAME_DATA / nStatus / pImgBuf / ...），
            % 之前的 'GxFrameData' + status/width/image_buf 会报「未找到类型」。
            framePtr = libpointer('GX_FRAME_DATA');
            v = framePtr.Value;
            v.pImgBuf  = obj.ImgBuf;
            v.nImgSize = obj.BufSize;
            framePtr.Value = v;

            st = calllib(obj.LIB, 'GXGetImage', obj.Handle, framePtr, uint32(timeoutMs));
            obj.check(st, 'GXGetImage');

            fr = framePtr.Value;
            if fr.nStatus ~= 0
                error('gx_camera:badFrame', '帧状态异常: %d（可能丢包或超时）', fr.nStatus);
            end

            w = double(fr.nWidth);
            h = double(fr.nHeight);
            if isempty(obj.ImgBuf) || obj.BufSize < w*h
                error('gx_camera:nullBuffer', '帧缓冲区不足（帧状态 %d）', fr.nStatus);
            end

            % 相机内存是行优先，MATLAB 是列优先，所以按 [w h] 解释后转置
            raw = obj.ImgBuf.Value;
            img = reshape(raw(1:w*h), w, h)';

            if nargout > 1
                m = struct('frame_id',  double(fr.nFrameID), ...
                           'timestamp', double(fr.nTimeStamp), ...
                           'host_time', toc(obj.Tic));
            end
        end

        % ===================== 关闭 =========================================
        function close(obj)
            if ~libisloaded(obj.LIB) || isempty(obj.Handle), return; end
            try
                calllib(obj.LIB, 'GXSendCommand', obj.Handle, ...
                        uint32(obj.FID.AcquisitionStop));
            catch
            end
            try
                calllib(obj.LIB, 'GXCloseDevice', obj.Handle);
            catch
            end
            obj.Handle = [];
        end

        function delete(obj)
            obj.close();
        end
    end

    methods (Static)
        function release_library()
        %RELEASE_LIBRARY  所有相机对象都 delete 之后再调用，卸载 DLL
            if libisloaded('GxIAPI')
                try, calllib('GxIAPI', 'GXCloseLib'); catch, end
                unloadlibrary('GxIAPI');
            end
        end
    end

    % ===================== 内部工具 =====================================
    methods (Access = private)
        function apply_roi(obj, w, h)
            % ROI 宽高受增量约束，先读 inc 再对齐，否则相机会拒绝
            wInc = max(1, double(obj.get_int_range_inc(obj.FID.Width)));
            hInc = max(1, double(obj.get_int_range_inc(obj.FID.Height)));
            w = floor(w / wInc) * wInc;
            h = floor(h / hInc) * hInc;
            obj.set_int(obj.FID.Width,  w, true);
            obj.set_int(obj.FID.Height, h, true);
        end

        function inc = get_int_range_inc(obj, fid)
            % 没有单独的 GXGetIntRange 声明时，用 1 兜底（大多数水星相机 inc=1/2）
            inc = 1;
            try
                rPtr = libpointer('GX_INT_RANGE');
                if calllib(obj.LIB, 'GXGetIntRange', obj.Handle, uint32(fid), rPtr) == 0
                    inc = double(rPtr.Value.nInc);
                end
            catch
            end
        end

        function set_enum(obj, fid, val, required)
            st = calllib(obj.LIB, 'GXSetEnum', obj.Handle, uint32(fid), int64(val));
            if required, obj.check(st, sprintf('GXSetEnum(0x%X)', fid)); end
        end

        function set_int(obj, fid, val, required)
            st = calllib(obj.LIB, 'GXSetInt', obj.Handle, uint32(fid), int64(val));
            if required, obj.check(st, sprintf('GXSetInt(0x%X)', fid)); end
        end

        function set_float(obj, fid, val, required)
            st = calllib(obj.LIB, 'GXSetFloat', obj.Handle, uint32(fid), double(val));
            if required, obj.check(st, sprintf('GXSetFloat(0x%X)', fid)); end
        end

        function v = get_int(obj, fid)
            p = libpointer('int64Ptr', 0);
            obj.check(calllib(obj.LIB, 'GXGetInt', obj.Handle, uint32(fid), p), 'GXGetInt');
            v = p.Value;
        end

        function v = get_float(obj, fid)
            p = libpointer('doublePtr', 0);
            obj.check(calllib(obj.LIB, 'GXGetFloat', obj.Handle, uint32(fid), p), 'GXGetFloat');
            v = p.Value;
        end

        function v = get_enum(obj, fid)
            p = libpointer('int32Ptr', 0);
            obj.check(calllib(obj.LIB, 'GXGetEnum', obj.Handle, uint32(fid), p), 'GXGetEnum');
            v = p.Value;
        end

        function dll = find_dll(~)
            % 统一走 galaxy_sdk_root()：环境变量 / config.json / 项目内 sdk/Win64
            % / 常见安装目录 / PATH，避免把某台机器的盘符写死。
            S = galaxy_sdk_root();
            if S.found
                dll = S.dll;
                p = getenv('PATH');
                if isempty(strfind(p, S.dir)) %#ok<STREMP>
                    setenv('PATH', [S.dir pathsep p]);
                end
            else
                dll = 'GxIAPI.dll';   % 最后交给系统 PATH 去找
            end
        end

        function check(~, status, what)
            if status == 0, return; end
            error('gx_camera:apiError', '%s 失败，错误码 %d（%s）', ...
                  what, status, gx_camera.err_text(status));
        end
    end

    methods (Static, Access = private)
        function s = err_text(code)
            persistent tbl
            if isempty(tbl)
                % 2026-11-06 按官方 GxIAPI.h 的 GX_STATUS_LIST 校正
                % （原表整体错位一位，曾把 -5 误报成「句柄无效」）
                tbl = containers.Map( ...
                    {-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14}, ...
                    {'GX_STATUS_ERROR 未知错误', ...
                     'GX_STATUS_NOT_FOUND_TL 找不到 TL 库', ...
                     'GX_STATUS_NOT_FOUND_DEVICE 没找到设备', ...
                     'GX_STATUS_OFFLINE 设备掉线', ...
                     'GX_STATUS_INVALID_PARAMETER 参数非法或指针为 NULL', ...
                     'GX_STATUS_INVALID_HANDLE 句柄无效', ...
                     'GX_STATUS_INVALID_CALL 调用顺序错误', ...
                     'GX_STATUS_INVALID_ACCESS 设备已被占用', ...
                     'GX_STATUS_NEED_MORE_BUFFER 缓冲区不足', ...
                     'GX_STATUS_ERROR_TYPE 功能码类型错误', ...
                     'GX_STATUS_OUT_OF_RANGE 数值越界', ...
                     'GX_STATUS_NOT_IMPLEMENTED 该型号不支持此功能', ...
                     'GX_STATUS_NOT_INIT_API 未调用 GXInitLib', ...
                     'GX_STATUS_TIMEOUT 超时'});
            end
            if isKey(tbl, code), s = tbl(code); else, s = '未收录错误码'; end
        end
    end
end
