function C = project_config()
%PROJECT_CONFIG  项目配置：优先读项目根 config.json，缺失时用内置默认值
%
%   换一台电脑时通常只需要编辑 config.json：
%     camera.K            相机内参（不同型号必须重新标定）
%     camera.exposure_us  曝光
%     camera.gain_code    增益 raw code
%     detection.tag_size_mm  标记物理边长
%     sdk.root            GalaxySDK 位置（留空自动探测）
%
%   也可用环境变量 ARUCO_SDK_ROOT / GALAXYSDK_ROOT 覆盖 SDK 位置，
%   无需改动项目文件。

    here = fileparts(mfilename('fullpath'));
    root = fileparts(here);

    C.Root        = root;
    C.ConfigFile  = fullfile(root, 'config.json');
    C.ResultsDir  = fullfile(root, 'results');
    C.SamplePhoto = fullfile(root, 'sample', 'two_markers_photo.jpg');
    C.HeaderFile  = fullfile(here, 'gxi_api.h');

    C.K             = [2133.3 0 646.0; 0 2133.3 482.0; 0 0 1];
    C.ExposureUs    = 50000;
    C.GainCode      = 400;
    C.GainFeatureID = '20001393';
    C.Width         = 1292;
    C.Height        = 964;

    C.MaxDim      = 720;
    C.TagSizeMM   = 50.0;
    C.Dictionary  = 'DICT_4X4_50';
    C.MarkerIDs   = [0 1];

    C.SdkRoot     = '';

    if exist(C.ConfigFile, 'file')
        try
            J = jsondecode(fileread(C.ConfigFile));
            if isfield(J, 'camera')
                a = J.camera;
                if isfield(a,'K') && numel(a.K) == 9
                    k = a.K;
                    if isequal(size(k), [3 3])
                        C.K = k;                        % JSON 二维数组已是 3x3
                    else
                        C.K = reshape(k(:), 3, 3).'; % 1x9 行优先展开
                    end
                end
                if isfield(a,'exposure_us'),  C.ExposureUs = a.exposure_us; end
                if isfield(a,'gain_code'),    C.GainCode = a.gain_code; end
                if isfield(a,'gain_feature_id'), C.GainFeatureID = a.gain_feature_id; end
                if isfield(a,'width'),        C.Width = a.width; end
                if isfield(a,'height'),       C.Height = a.height; end
            end
            if isfield(J, 'detection')
                d = J.detection;
                if isfield(d,'max_dim'),      C.MaxDim = d.max_dim; end
                if isfield(d,'tag_size_mm'),  C.TagSizeMM = d.tag_size_mm; end
                if isfield(d,'dictionary'),   C.Dictionary = d.dictionary; end
                if isfield(d,'marker_ids'),   C.MarkerIDs = d.marker_ids(:)'; end
            end
            if isfield(J, 'sdk') && isfield(J.sdk, 'root')
                C.SdkRoot = J.sdk.root;
            end
        catch e
            warning('project_config:badJson', ...
                    'config.json 无法解析，已使用内置默认值：%s', e.message);
        end
    end

    v = getenv('ARUCO_SDK_ROOT');
    if isempty(v), v = getenv('GALAXYSDK_ROOT'); end
    if ~isempty(v), C.SdkRoot = v; end
end
