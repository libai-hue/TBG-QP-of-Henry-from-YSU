function n = camera_count()
%CAMERA_COUNT  轻量枚举大恒相机：只 InitLib + UpdateDeviceList
%
%   n > 0  在线设备数
%   n = 0  没有设备（USB 掉线 / 未插 / 被占用）
%   n < 0  无法枚举（SDK 未安装，或 loadlibrary 未配置编译器）
%
%   不打开设备、不启动采集、不占用相机，可在任何时候调用。

    n = -1;
    S = galaxy_sdk_root();
    if ~S.found, return; end
    try
        sdkDir = S.dir;
        p = getenv('PATH');
        if isempty(strfind(p, sdkDir)) %#ok<STREMP>
            setenv('PATH', [sdkDir pathsep p]);   % 让依赖 DLL 可被找到
        end
        if ~libisloaded('GxIAPI')
            loadlibrary(S.dll, S.header, 'alias', 'GxIAPI');
        end
        calllib('GxIAPI', 'GXInitLib');
        np = libpointer('uint32Ptr', 0);
        calllib('GxIAPI', 'GXUpdateDeviceList', np, uint32(1000));
        n = double(np.Value);
        calllib('GxIAPI', 'GXCloseLib');
    catch
        n = -1;
    end
end
