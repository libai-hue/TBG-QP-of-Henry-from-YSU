function R = preflight(verbose)
%PREFLIGHT  换电脑后的环境预检：把「缺什么」直接说清楚，不要让错误藏在 MATLAB 深处
%
%   R = preflight()        打印报告
%   R = preflight(false)   静默
%
%   R.ok          照片演示 / 自检能否运行
%   R.canRealtime 真实相机实时识别能否运行
%   R.issues      致命问题清单（阻断演示）
%   R.warnings    非致命问题清单（阻断实时，但不阻断演示）

    if nargin < 1 || isempty(verbose), verbose = true; end
    C = project_config();
    S = galaxy_sdk_root();
    R = struct('ok', true, 'canRealtime', true, 'issues', {{}}, ...
               'warnings', {{}}, 'sdk', S, 'config', C);

    if verbose
        fprintf('\n--- environment preflight ---\n');
        fprintf('  MATLAB   : %s / %s\n', version, computer('arch'));
        fprintf('  folder   : %s\n', C.Root);
    end

    % 1) 64 位 MATLAB（GalaxySDK 只提供 x64）
    is64 = ~isempty(strfind(computer('arch'), '64')); %#ok<STREMP>
    R = say(verbose, '64-bit MATLAB', is64, is64, ...
        '需要 64 位 MATLAB；GalaxySDK 没有 32 位库', R);

    % 2) Image Processing Toolbox
    hasIPT = (exist('adaptthresh','file') == 2) && ...
             (exist('bwboundaries','file') == 2) && ...
             (exist('imresize','file') == 2);
    R = say(verbose, 'Image Processing Toolbox', hasIPT, true, ...
        '请安装 Image Processing Toolbox（需要 adaptthresh / bwboundaries）', R);

    isWin = ispc;   % 相机驱动 gx_camera.m 目前只适配 Windows 的 GxIAPI.dll

    % 3) C++ 编译器（loadlibrary 生成 thunk 用；只影响实时相机）
    compilerName = '';
    try
        cc = mex.getCompilerConfigurations('C++');
        if ~isempty(cc), compilerName = cc(1).Name; end
    catch
    end
    hasCompiler = ~isempty(compilerName);
    if isWin
        R = say(verbose, 'C++ compiler (loadlibrary)', hasCompiler, false, ...
            '执行 mex -setup C++ 选择 VS2022；仅实时相机需要', R);
    elseif verbose
        fprintf('  [INFO] C++ compiler check skipped (Windows camera driver only)\n');
    end

    % 4) GalaxySDK（只影响实时相机；macOS/Linux 不适用 Windows DLL）
    if isWin
        R = say(verbose, 'GalaxySDK GxIAPI.dll', S.found, false, ...
            '安装大恒 GalaxySDK，或设 ARUCO_SDK_ROOT，或把 DLL 放到项目 sdk\\Win64\\', R);
        if S.found && verbose
            fprintf('             -> %s\n', S.source);
        end
    else
        if verbose
            fprintf('  [INFO] GalaxySDK Windows DLL not applicable on %s\n', computer('arch'));
            fprintf('         -> photo demo works; live camera needs a macOS SDK port\n');
        end
        R.warnings{end+1} = ['Live camera: gx_camera.m is Windows-specific ' ...
            '(GxIAPI.dll / loadlibrary). A macOS GalaxySDK port is required.'];
    end

    % 5) loadlibrary 头文件（随项目携带）
    hasHeader = exist(C.HeaderFile, 'file') == 2;
    R = say(verbose, 'gxi_api.h next to sources', hasHeader, false, ...
        'gxi_api.h 必须与 gx_camera.m 在同一目录', R);

    % 6) 示例照片 + config.json
    hasPhoto = exist(C.SamplePhoto, 'file') == 2;
    R = say(verbose, 'sample/two_markers_photo.jpg', hasPhoto, true, ...
        '示例照片缺失，演示模式无法运行', R);
    hasCfg = exist(C.ConfigFile, 'file') == 2;
    R = say(verbose, 'config.json', hasCfg, false, ...
        '未找到 config.json，将使用内置默认参数', R);

    % 7) results 目录可写（放在 Program Files 等只读位置会失败）
    if ~exist(C.ResultsDir, 'dir')
        try
            mkdir(C.ResultsDir);
        catch
        end
    end
    probe = fullfile(C.ResultsDir, '_write_test.tmp');
    fid = fopen(probe, 'w');
    writable = fid > 0;
    if writable, fwrite(fid, 'ok', 'char'); fclose(fid); delete(probe); end
    R = say(verbose, 'results/ writable', writable, true, ...
        '把整个文件夹移到有写权限的位置（不要放在 Program Files）', R);

    R.ok = hasIPT && hasPhoto && writable;
    R.canRealtime = R.ok && isWin && hasCompiler && S.found && hasHeader && is64;
    if verbose
        fprintf('  --------------------------------------------\n');
        fprintf('  photo demo : %s\n', tf(R.ok));
        fprintf('  realtime   : %s\n', tf(R.canRealtime));
        fprintf('  --------------------------------------------\n\n');
    end
end

function R = say(verbose, label, ok, critical, hint, R)
    if ok
        tag = '[OK]  ';
    elseif critical
        tag = '[FAIL]';
    else
        tag = '[WARN]';
    end
    if verbose
        fprintf('  %s %-32s %s\n', tag, label, tf(ok));
        if ~ok, fprintf('         -> %s\n', hint); end
    end
    if ~ok
        text = [label ': ' hint];
        if critical
            R.issues{end+1} = text;
        else
            R.warnings{end+1} = text;
        end
    end
end

function s = tf(b)
    if b, s = 'ready'; else, s = 'missing'; end
end
