function R = aruco_solve_frame(frame, K, verbose, opts)
%ARUCO_SOLVE_FRAME  纯 MATLAB 逐帧 ArUco 检测 + 两标记相对位姿（实时核心）
%
%   R = aruco_solve_frame(frame)                % 自标定焦距（单张照片用）
%   R = aruco_solve_frame(frame, K)             % 用给定内参（实时相机用）
%   R = aruco_solve_frame(frame, K, false)      % 静默，供高频循环调用
%   opts  : struct，可含 .MaxDim (默认 0=不缩放)、.Fast (默认 false)
%           .MaxDim=720 会先缩小再检测，角点自动换算回原分辨率，可显著提速
%
%   frame : MxN uint8 灰度，或 MxNx3 RGB
%   K     : 3x3 内参；[] 表示用平面单应性自标定等效焦距
%   返回 R: struct
%       ok, ids, q0, q1, hamming, f_px, K,
%       t0_mm, t1_mm, delta_mm, distance_mm, rotation_deg, T_A_B,
%       plane_crosscheck_mm, engine
%
%   运行时不调用 Python / OpenCV / MEX；只依赖 Image Processing Toolbox
%   与 MATLAB 基础矩阵运算。码本 aruco_dict_4x4_50.m 为字典常量数据。

    if nargin < 3 || isempty(verbose), verbose = false; end
    if nargin < 2, K = []; end
    if nargin < 4 || isempty(opts), opts = struct(); end
    if ~isfield(opts, 'MaxDim'), opts.MaxDim = 0; end

    % 标记物理边长：默认 50 mm，可由 config.json -> project_config 覆盖
    TAG_MM = 50.0;
    if isfield(opts, 'TagSizeMM') && isnumeric(opts.TagSizeMM) && ...
            isscalar(opts.TagSizeMM) && opts.TagSizeMM > 0
        TAG_MM = double(opts.TagSizeMM);
    end
    if size(frame, 3) == 3
        gray0 = rgb2gray(frame);
    else
        gray0 = frame;
    end
    [H0, W0] = size(gray0);
    % 可选降采样：检测在低分辨率上做，角点/内参按比例换算回原分辨率
    sc = 1.0;
    if opts.MaxDim > 0 && max(H0, W0) > opts.MaxDim
        sc = opts.MaxDim / max(H0, W0);
        gray = imresize(gray0, sc);
    else
        gray = gray0;
    end
    [H, W] = size(gray);
    cx = W / 2; cy = H / 2;

    R = struct('ok', false, 'ids', [0 1], 'q0', [], 'q1', [], ...
               'hamming', [inf inf], 'f_px', NaN, 'K', [], ...
               't0_mm', [], 't1_mm', [], 'delta_mm', [], ...
               'distance_mm', NaN, 'rotation_deg', NaN, 'T_A_B', [], ...
               'plane_crosscheck_mm', [], ...
               'engine', 'MATLAB pure M (no Python / OpenCV / MEX)');

    % ---------- 自适应阈值 + 连通域轮廓 ----------
    T = adaptthresh(gray, 0.45, 'NeighborhoodSize', 51, 'Statistic', 'gaussian');
    BW = imbinarize(gray, T);
    BW = bwareaopen(BW, 40);
    BW = imclose(BW, strel('square', 3));
    dark = bwareaopen(~BW, 60);
    B = bwboundaries(dark, 'noholes');

    D = aruco_dict_4x4_50();
    EPS_FACTORS = [0.005, 0.01, 0.015, 0.02, 0.03, 0.04, 0.06];
    best = containers.Map('KeyType', 'double', 'ValueType', 'any');

    for k = 1:numel(B)
        pts = B{k};
        if size(pts, 1) < 20, continue; end
        xy = [pts(:, 2), pts(:, 1)];
        perim = sum(sqrt(sum(diff([xy; xy(1, :)]).^2, 2)));
        poly = quadFromContour(xy, perim, EPS_FACTORS);
        if isempty(poly), continue; end
        area = polyarea(poly(:, 1), poly(:, 2));
        if area < 400 || area > 0.35 * H * W, continue; end
        side = zeros(4, 1);
        for s = 1:4
            side(s) = norm(poly(mod(s, 4) + 1, :) - poly(s, :));
        end
        if min(side) < 20 || max(side) / max(min(side), 1) > 4, continue; end

        q = orderQuad(poly);
        [id, dd, rot] = decodeMarker(BW, q, D);
        if dd <= 2 && (id == 0 || id == 1)
            if ~isKey(best, id) || dd < best(id).dist
                best(id) = struct('id', id, 'quad', q, 'dist', dd, 'rot', rot);
            end
        end
    end

    if ~isKey(best, 0) || ~isKey(best, 1)
        if verbose, fprintf('[solveFrame] missing markers\n'); end
        return;
    end
    A = best(0); Bm = best(1);
    % 角点换算回原始分辨率，供画图与后续使用
    R.q0 = A.quad / sc; R.q1 = Bm.quad / sc;
    A.quad = A.quad / sc; Bm.quad = Bm.quad / sc;
    R.hamming = [A.dist, Bm.dist];
    [H, W] = size(gray0); cx = W / 2; cy = H / 2;

    % ---------- 内参：给定则用给定，否则平面单应性自标定 ----------
    obj = [-TAG_MM/2 -TAG_MM/2; TAG_MM/2 -TAG_MM/2;
            TAG_MM/2  TAG_MM/2; -TAG_MM/2  TAG_MM/2];
    HA = homography(obj, A.quad);
    HB = homography(obj, Bm.quad);
    if isempty(K)
        fv = [focalFromH(HA, cx, cy), focalFromH(HB, cx, cy)];
        fv = fv(isfinite(fv) & fv > 0 & fv < 20 * W);
        if isempty(fv), f = 1.2 * W; else, f = median(fv); end
        K = [f 0 cx; 0 f cy; 0 0 1];
    end
    R.K = K; R.f_px = K(1, 1);

    % ---------- PnP（单应性分解）+ 相对位姿 ----------
    [RA, tA] = poseFromH(HA, K);
    [RB, tB] = poseFromH(HB, K);
    TCA = [RA, tA(:); 0 0 0 1];
    TCB = [RB, tB(:); 0 0 0 1];
    Trel = TCA \ TCB;
    delta = Trel(1:3, 4);
    [angle, ~] = rotToAxisAngle(Trel(1:3, 1:3));

    dst = [0 0; TAG_MM 0; TAG_MM TAG_MM; 0 TAG_MM];
    Bp = applyH(homography(A.quad, dst), Bm.quad);
    dplane = mean(Bp, 1) - [TAG_MM/2, TAG_MM/2];

    R.ok = true;
    R.t0_mm = tA; R.t1_mm = tB;
    R.delta_mm = delta;
    R.distance_mm = norm(delta);
    R.rotation_deg = angle;
    R.T_A_B = Trel;
    R.plane_crosscheck_mm = dplane;
    if verbose
        fprintf('[solveFrame] ID0/1 ham=%d/%d f=%.0f | dX=%+.1f dY=%+.1f dZ=%+.1f D=%.1f rot=%.1f\n', ...
                A.dist, Bm.dist, R.f_px, delta(1), delta(2), delta(3), ...
                R.distance_mm, angle);
    end
end

% ======================= 子函数 =======================

function poly = quadFromContour(xy, perim, epsFactors)
    n = size(xy, 1);
    poly = [];
    starts = unique([1, round(n * (0.125:0.125:0.875))]);
    for si = 1:numel(starts)
        s = starts(si);
        z = [xy(s:end, :); xy(1:s-1, :); xy(s, :)];
        for ei = 1:numel(epsFactors)
            pp = rdp(z, epsFactors(ei) * perim);
            if size(pp, 1) == 5
                cand = pp(1:end-1, :);
                if isConvexQuad(cand), poly = cand; return; end
            end
        end
    end
end

function p = rdp(p, eps)
    if size(p, 1) < 3, return; end
    a = p(1, :); b = p(end, :);
    ab = b - a; L2 = ab * ab';
    if L2 < 1e-9
        d = sqrt(sum((p - a).^2, 2));
    else
        t = max(0, min(1, ((p - a) * ab') / L2));
        d = sqrt(sum((p - (a + t * ab)).^2, 2));
    end
    [mx, ix] = max(d);
    if mx > eps && ix > 1 && ix < size(p, 1)
        p1 = rdp(p(1:ix, :), eps);
        p2 = rdp(p(ix:end, :), eps);
        p = [p1(1:end-1, :); p2];
    else
        p = [a; b];
    end
end

function tf = isConvexQuad(q)
    q = orderQuad(q);
    cr = zeros(4, 1);
    for k = 1:4
        a = q(k, :); b = q(mod(k, 4) + 1, :); c = q(mod(k + 1, 4) + 1, :);
        cr(k) = (b(1)-a(1))*(c(2)-b(2)) - (b(2)-a(2))*(c(1)-b(1));
    end
    tf = all(cr > 0) || all(cr < 0);
end

function q = orderQuad(p)
    s = sum(p, 2); d = p(:, 1) - p(:, 2);
    [~, iTL] = min(s); [~, iBR] = max(s);
    [~, iTR] = max(d); [~, iBL] = min(d);
    idx = [iTL, iTR, iBR, iBL];
    if numel(unique(idx)) < 4
        [~, ord] = sort(atan2(p(:, 2)-mean(p(:, 2)), p(:, 1)-mean(p(:, 1))));
        q = p(ord, :);
    else
        q = p(idx, :);
    end
end

function H = homography(src, dst)
    A = zeros(8, 9);
    for i = 1:4
        x = src(i,1); y = src(i,2); u = dst(i,1); v = dst(i,2);
        A(2*i-1,:) = [x y 1 0 0 0 -u*x -u*y -u];
        A(2*i,  :) = [0 0 0 x y 1 -v*x -v*y -v];
    end
    [~, ~, V] = svd(A, 0);
    H = reshape(V(:, end), 3, 3)';
    H = H / H(3, 3);
end

function p = applyH(H, pts)
    p = (H * [pts, ones(size(pts, 1), 1)]')';
    p = p(:, 1:2) ./ p(:, 3);
end

function [id, bestD, rot] = decodeMarker(BW, q, D)
    c = [0 0; 6 0; 6 6; 0 6];
    HH = homography(c, q);
    [X, Y] = meshgrid(0.5:5.5, 0.5:5.5);
    uv = applyH(HH, [X(:), Y(:)]);
    vals = interp2(double(BW), uv(:, 1), uv(:, 2), 'nearest', 0);
    bw6 = reshape(vals > 0.5, 6, 6);
    code = logical(bw6(2:5, 2:5));
    id = -1; bestD = inf; rot = 0;
    for inv = 0:1
        base = code; if inv, base = ~code; end
        for r = 0:3
            cc = rot90(base, -r);
            rowmajor = reshape(cc.', 1, []);   % 码本为行优先
            for m = 0:size(D, 1) - 1
                dd = sum(rowmajor ~= D(m+1, :));
                if dd < bestD, bestD = dd; id = m; rot = r + 4*inv; end
            end
        end
    end
end

function f = focalFromH(H, cx, cy)
    h1 = H(:, 1); h2 = H(:, 2);
    M = [1 0 -cx; 0 1 -cy; -cx -cy cx*cx + cy*cy];
    N = zeros(3); N(3, 3) = 1;
    a = h1' * M * h2;
    b = h1' * N * h2;
    if abs(a) < 1e-12, f = NaN; return; end
    w = -b / a;
    if w <= 1e-12, f = NaN; else, f = 1 / sqrt(w); end
end

function [R, t] = poseFromH(H, K)
    G = K \ H;
    lam = 2 / (norm(G(:, 1)) + norm(G(:, 2)));
    r1 = lam * G(:, 1); r2 = lam * G(:, 2);
    t = lam * G(:, 3);
    r3 = cross(r1, r2);
    [U, ~, V] = svd([r1, r2, r3]);
    R = U * V';
    if det(R) < 0, R = -R; end
    if t(3) < 0, t = -t; end
end

function [ang, ax] = rotToAxisAngle(R)
    w = [R(3,2)-R(2,3); R(1,3)-R(3,1); R(2,1)-R(1,2)] / 2;
    c = max(-1, min(1, (trace(R) - 1) / 2));
    th = acos(c);
    s = norm(w);
    if th < 1e-8, ang = 0; ax = [0 0 1]; return; end
    if s > 1e-8, r = th * w / s; else, r = [0 0 0]; end
    n = norm(r);
    if n < 1e-12, ang = 0; ax = [0 0 1]; return; end
    ang = rad2deg(n); ax = r / n;
end
