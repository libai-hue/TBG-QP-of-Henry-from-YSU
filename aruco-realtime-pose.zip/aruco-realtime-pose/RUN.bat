@echo off
setlocal
rem ============================================================
rem  realtime_aruco_pose - PORTABLE one-click launcher (USB friendly)
rem
rem  Double-click RUN.bat      auto: ready -> realtime; not ready -> photo demo
rem  RUN.bat check             full environment preflight + self test
rem  RUN.bat demo              photo demo only, never touches the camera
rem  RUN.bat live              force realtime (error if prerequisites missing)
rem
rem  THIS FOLDER IS PORTABLE. All paths are derived from %%~dp0.
rem  On another PC you normally need NOTHING but MATLAB installed.
rem  Optional overrides (edit the two lines below, or set environment vars):
rem ============================================================

rem ---- OPTIONAL MANUAL OVERRIDES --------------------------------
rem set "ARUCO_MATLAB_EXE=C:\Program Files\MATLAB\R2024b\bin\matlab.exe"
rem set "ARUCO_SDK_ROOT=C:\GalaxySDK\APIDll\Win64"

set "PROJ=%~dp0"
set "MODE=%~1"
if /I "%MODE%"=="live" set "MODE=realtime"
if "%MODE%"=="" set "MODE=auto"

echo.
echo ============================================================
echo  realtime_aruco_pose  [PORTABLE]   mode = %MODE%
echo  folder = %PROJ%
echo ============================================================
echo.

rem ---- 0. basic folder checks -----------------------------------
if not exist "%PROJ%matlab\run_project.m" (
  echo [ERROR] matlab\run_project.m is missing - folder is incomplete.
  goto :fail
)
if not exist "%PROJ%results" mkdir "%PROJ%results" 2>nul
if not exist "%PROJ%results" (
  echo [ERROR] cannot create results folder. Move this folder somewhere writable.
  goto :fail
)
echo. > "%PROJ%results\_write_test.tmp" 2>nul
if not exist "%PROJ%results\_write_test.tmp" (
  echo [ERROR] results folder is NOT writable.
  echo         Move the folder out of Program Files / read-only media.
  goto :fail
)
del "%PROJ%results\_write_test.tmp" >nul 2>&1
echo [OK]   folder writable

rem ---- 1. locate MATLAB -----------------------------------------
set "MATLAB_EXE="
if defined ARUCO_MATLAB_EXE set "MATLAB_EXE=%ARUCO_MATLAB_EXE%"
if defined MATLAB_EXE_PATH if not defined MATLAB_EXE set "MATLAB_EXE=%MATLAB_EXE_PATH%"
if not defined MATLAB_EXE if exist "D:\matlab\bin\matlab.exe" set "MATLAB_EXE=D:\matlab\bin\matlab.exe"
for /d %%V in ("C:\Program Files\MATLAB\*") do if exist "%%V\bin\matlab.exe" set "MATLAB_EXE=%%V\bin\matlab.exe"
for /d %%V in ("C:\Program Files (x86)\MATLAB\*") do if exist "%%V\bin\matlab.exe" set "MATLAB_EXE=%%V\bin\matlab.exe"
for /d %%V in ("D:\MATLAB\*") do if exist "%%V\bin\matlab.exe" set "MATLAB_EXE=%%V\bin\matlab.exe"
for /d %%V in ("D:\Program Files\MATLAB\*") do if exist "%%V\bin\matlab.exe" set "MATLAB_EXE=%%V\bin\matlab.exe"
if not defined MATLAB_EXE (
  for /f "delims=" %%i in ('where matlab 2^>nul') do if not defined MATLAB_EXE set "MATLAB_EXE=%%i"
)
if not defined MATLAB_EXE (
  echo.
  echo [ERROR] MATLAB not found on this PC.
  echo         This project REQUIRES MATLAB R2018b+ with Image Processing Toolbox.
  echo         Fix: set ARUCO_MATLAB_EXE at the top of RUN.bat, or add MATLAB to PATH.
  goto :fail
)
echo [OK]   MATLAB   : %MATLAB_EXE%

rem ---- 2. locate GalaxySDK (optional: demo works without it) ----
set "SDK_DIR="
if defined ARUCO_SDK_ROOT set "SDK_DIR=%ARUCO_SDK_ROOT%"
if not defined SDK_DIR if exist "%PROJ%sdk\Win64\GxIAPI.dll" set "SDK_DIR=%PROJ%sdk\Win64"
if not defined SDK_DIR (
  for %%D in ("D:\GalaxySDK\APIDll\Win64" "C:\GalaxySDK\APIDll\Win64" "C:\Program Files\Daheng Imaging\GalaxySDK\APIDll\Win64" "C:\Program Files (x86)\Daheng Imaging\GalaxySDK\APIDll\Win64" "C:\Program Files\GalaxySDK\APIDll\Win64" "D:\Program Files\Daheng\GalaxySDK\APIDll\Win64") do if exist "%%~D\GxIAPI.dll" set "SDK_DIR=%%~D"
)
if defined SDK_DIR (
  set "ARUCO_SDK_ROOT=%SDK_DIR%"
  echo [OK]   SDK      : %SDK_DIR%
) else (
  echo [WARN] GalaxySDK not found - realtime camera disabled, PHOTO DEMO still works.
  echo         Fix: install GalaxySDK, or set ARUCO_SDK_ROOT, or put DLLs in sdk\Win64\.
)

rem ---- 3. config / dashboard ------------------------------------
if exist "%PROJ%config.json" (
  echo [OK]   config   : config.json
) else (
  echo [WARN] config.json missing - built-in defaults will be used
)
if /I "%MODE%" NEQ "check" (
  if exist "%PROJ%results\realtime_dashboard.html" (
    start "" "%PROJ%results\realtime_dashboard.html"
    echo [OK]   dashboard opened in browser
  )
)

echo.
echo Starting MATLAB. Keep THIS console open.
echo   realtime : press Ctrl-C or close this console to STOP
echo   missing prerequisites are listed by the MATLAB preflight below
echo.

"%MATLAB_EXE%" -batch "cd('%PROJ%matlab'); run_project('%MODE%')"
set "RC=%ERRORLEVEL%"

echo.
echo MATLAB exited with code %RC%.
if not "%RC%"=="0" (
  echo [HINT] Run  RUN.bat check  to see exactly what is missing on this PC.
)
echo.
pause
exit /b %RC%

:fail
echo.
echo Setup incomplete. See README.md section 2 (another PC checklist).
pause
exit /b 1
