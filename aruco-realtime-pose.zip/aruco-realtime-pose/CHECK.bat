@echo off
rem Double-click to run the full environment preflight + self test
call "%~dp0RUN.bat" check
