#!/usr/bin/env bash
# realtime_aruco_pose - macOS / Linux launcher
#
#   bash run_mac.sh                    photo demo (default)
#   bash run_mac.sh check              environment preflight + self test
#   bash run_mac.sh image /path/x.jpg  solve one image
#
# On macOS, if you prefer double-clicking RUN.command, run once:
#   chmod +x RUN.command
# (FAT32 USB drives do not preserve executable bits.)

set -u
PROJ="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-demo}"
IMG="${2:-}"

echo ""
echo "============================================================"
echo " realtime_aruco_pose  [macOS / Linux]   mode = $MODE"
echo " folder = $PROJ"
echo "============================================================"
echo ""

# ---- folder checks ----
if [ ! -f "$PROJ/matlab/run_mac.m" ]; then
  echo "[ERROR] matlab/run_mac.m missing - folder is incomplete."
  exit 1
fi
mkdir -p "$PROJ/results" 2>/dev/null
if [ ! -w "$PROJ/results" ]; then
  echo "[ERROR] results folder is not writable. Copy this folder to a writable location."
  exit 1
fi
echo "[OK]   folder writable"

# ---- locate MATLAB ----
MATLAB_EXE="${ARUCO_MATLAB_EXE:-}"
if [ -z "$MATLAB_EXE" ]; then
  for app in /Applications/MATLAB_*.app; do
    [ -x "$app/bin/matlab" ] && MATLAB_EXE="$app/bin/matlab"
  done
fi
if [ -z "$MATLAB_EXE" ] && [ -x /Applications/MATLAB.app/bin/matlab ]; then
  MATLAB_EXE=/Applications/MATLAB.app/bin/matlab
fi
if [ -z "$MATLAB_EXE" ] && command -v matlab >/dev/null 2>&1; then
  MATLAB_EXE="$(command -v matlab)"
fi
if [ -z "$MATLAB_EXE" ]; then
  echo "[ERROR] MATLAB not found. Install 64-bit MATLAB + Image Processing Toolbox,"
  echo "        or set ARUCO_MATLAB_EXE=/path/to/matlab"
  exit 1
fi
echo "[OK]   MATLAB   : $MATLAB_EXE"

if [ -f "$PROJ/config.json" ]; then
  echo "[OK]   config   : config.json"
else
  echo "[WARN] config.json missing - built-in defaults will be used"
fi
echo "[INFO] live camera capture is Windows-only in this build;"
echo "       photo demo / single-image solving work fully on macOS."
echo ""

# ---- open dashboard ----
if [ -f "$PROJ/results/realtime_dashboard.html" ]; then
  if command -v open >/dev/null 2>&1; then
    open "$PROJ/results/realtime_dashboard.html" 2>/dev/null || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$PROJ/results/realtime_dashboard.html" 2>/dev/null || true
  fi
fi

# ---- run MATLAB ----
if [ "$MODE" = "image" ] && [ -n "$IMG" ]; then
  CMD="cd('$PROJ/matlab'); run_mac('image','$IMG')"
else
  CMD="cd('$PROJ/matlab'); run_mac('$MODE')"
fi
echo "Starting MATLAB (-batch). This terminal stays open until it finishes."
echo ""
"$MATLAB_EXE" -batch "$CMD"
RC=$?
echo ""
echo "MATLAB exited with code $RC."
if [ "$RC" -ne 0 ]; then
  echo "[HINT] Run: bash run_mac.sh check   to see what is missing."
fi
exit $RC
