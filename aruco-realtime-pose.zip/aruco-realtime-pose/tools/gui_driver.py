# -*- coding: utf-8 -*-
"""Windows GUI 驱动：用原生键盘/窗口消息操作 VS / MATLAB，并截屏留证。

注意：本模块不采集相机、不跑实验逻辑，只负责「把软件窗口打开、激活、
敲键盘、截屏」。相机读数发生在 VS 程序和 MATLAB 命令窗口内部。

用法（分步驱动，便于观察每一步界面）：
    python tools/gui_driver.py windows
    python tools/gui_driver.py launch --which vs
    python tools/gui_driver.py launch --which matlab
    python tools/gui_driver.py activate --title "Microsoft Visual Studio" --shot vs_front.png
    python tools/gui_driver.py keys --title "MATLAB" --text "gui_live_capture" --enter --shot matlab_cmd.png
    python tools/gui_driver.py hotkey --title "Microsoft Visual Studio" --combo ctrl+f5 --shot vs_run.png
"""
from __future__ import annotations

import argparse
import ctypes
import os
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path
from typing import List, Optional

from PIL import ImageGrab

ROOT = Path(__file__).resolve().parents[1]
SHOT_DIR = ROOT / "results" / "gui_steps"
SHOT_DIR.mkdir(parents=True, exist_ok=True)

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

# 关键：让本进程 DPI-aware，否则截图是物理像素、鼠标坐标却是逻辑像素，
# 在 125%/150% 缩放下点击会整体偏移（曾误点到 MATLAB 地址栏）。
try:
    ctypes.WinDLL("shcore").SetProcessDpiAwareness(2)   # PER_MONITOR_AWARE
except Exception:
    try:
        user32.SetProcessDPIAware()
    except Exception:
        pass

KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
VK_RETURN = 0x0D
VK_CONTROL = 0x11
VK_SHIFT = 0x10
VK_F5 = 0x74
VK_F4 = 0x73
VK_ESCAPE = 0x1B
SW_RESTORE = 9
SW_SHOW = 5

VS_EXE = r"C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\devenv.exe"
VS_SLN = r"D:\vs\Project1_DaHeng\Project1_DaHeng.sln"
MATLAB_EXE = r"D:\matlab\bin\matlab.exe"
MATLAB_CWD = ROOT / "matlab"
# 本项目自带的示例标注图（内置常量，避免 shell 转义）
PHOTO_FRAME_PNG = str(ROOT / "results" / "matlab_native_pose.png")

EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.EnumWindows.argtypes = [EnumWindowsProc, wintypes.LPARAM]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_void_p]


def list_windows() -> List[dict]:
    out: List[dict] = []

    def cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        out.append({"hwnd": int(hwnd), "pid": int(pid.value), "title": buf.value})
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return out


def find_window(title_substr: str) -> Optional[dict]:
    key = title_substr.lower()
    for w in list_windows():
        if key in w["title"].lower():
            return w
    return None


def activate(title_substr: str, wait: float = 0.4) -> dict:
    w = find_window(title_substr)
    if w is None:
        raise RuntimeError("找不到窗口: %s\n现有窗口:\n%s"
                           % (title_substr,
                              "\n".join("  %s" % x["title"] for x in list_windows())))
    hwnd = w["hwnd"]
    user32.ShowWindow(hwnd, SW_RESTORE)
    # AttachThreadInput 让跨进程 SetForegroundWindow 更可靠
    fg = user32.GetForegroundWindow()
    cur_tid = kernel32.GetCurrentThreadId()
    fg_tid = user32.GetWindowThreadProcessId(fg, None) if fg else 0
    if fg_tid and fg_tid != cur_tid:
        user32.AttachThreadInput(cur_tid, fg_tid, True)
        user32.SetForegroundWindow(hwnd)
        user32.AttachThreadInput(cur_tid, fg_tid, False)
    else:
        user32.SetForegroundWindow(hwnd)
    user32.BringWindowToTop(hwnd)
    time.sleep(wait)
    return w


ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD)]


class INPUTUNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]


INPUT_KEYBOARD = 1
user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
user32.SendInput.restype = wintypes.UINT


def _send(vk: int, scan: int, flags: int) -> None:
    inp = INPUT()
    inp.type = INPUT_KEYBOARD
    inp.ki = KEYBDINPUT(wintypes.WORD(vk), wintypes.WORD(scan),
                        wintypes.DWORD(flags), 0, ULONG_PTR(0))
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def _key_down(vk: int, scan: int = 0, flags: int = 0) -> None:
    _send(vk, scan, flags)


def _key_up(vk: int, scan: int = 0, flags: int = 0) -> None:
    _send(vk, scan, flags | KEYEVENTF_KEYUP)


def type_text(text: str, delay: float = 0.004) -> None:
    """SendInput + KEYEVENTF_UNICODE：对 MATLAB(Java) 命令窗口也有效。"""
    for ch in text:
        code = ord(ch)
        _key_down(0, code, KEYEVENTF_UNICODE)
        _key_up(0, code, KEYEVENTF_UNICODE)
        time.sleep(delay)


CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
user32.OpenClipboard.argtypes = [wintypes.HWND]
user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]


def set_clipboard(text: str) -> None:
    data = text.encode("utf-16-le") + b"\x00\x00"
    h = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
    ptr = kernel32.GlobalLock(h)
    ctypes.memmove(ptr, data, len(data))
    kernel32.GlobalUnlock(h)
    if not user32.OpenClipboard(None):
        raise RuntimeError("OpenClipboard 失败")
    user32.EmptyClipboard()
    user32.SetClipboardData(CF_UNICODETEXT, h)
    user32.CloseClipboard()


def paste(text: str) -> None:
    set_clipboard(text)
    _key_down(VK_CONTROL)
    press(ord("V"))
    _key_up(VK_CONTROL)
    time.sleep(0.3)


def press(vk: int) -> None:
    _key_down(vk)
    time.sleep(0.02)
    _key_up(vk)
    time.sleep(0.05)


def hotkey(combo: str) -> None:
    parts = [p.strip().lower() for p in combo.split("+")]
    mods = {"ctrl": VK_CONTROL, "shift": VK_SHIFT}
    vkmap = {"f5": VK_F5, "f4": VK_F4, "enter": VK_RETURN,
             "esc": VK_ESCAPE, "return": VK_RETURN}
    held = [mods[p] for p in parts[:-1] if p in mods]
    main = parts[-1]
    vk = vkmap.get(main) or (ord(main.upper()) if len(main) == 1 else None)
    if vk is None:
        raise ValueError("不支持的按键: %s" % combo)
    for h in held:
        _key_down(h)
    press(vk)
    for h in reversed(held):
        _key_up(h)
    time.sleep(0.3)


EnumChildProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.EnumChildWindows.argtypes = [wintypes.HWND, EnumChildProc, wintypes.LPARAM]
user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                wintypes.LPARAM]
BM_CLICK = 0x00F5
WM_CLOSE = 0x0010
WM_SETTEXT = 0x000C


def child_buttons(title_substr: str) -> List[dict]:
    w = find_window(title_substr)
    if w is None:
        return []
    out: List[dict] = []

    def cb(hwnd, _):
        n = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        cls = ctypes.create_unicode_buffer(128)
        user32.GetClassNameW(hwnd, cls, 128)
        out.append({"hwnd": int(hwnd), "class": cls.value, "text": buf.value})
        return True

    user32.EnumChildWindows(w["hwnd"], EnumChildProc(cb), 0)
    return out


def click_button(dialog_title: str, button_text: str, wait: float = 0.6) -> None:
    w = find_window(dialog_title)
    if w is None:
        raise RuntimeError("找不到对话框: %s" % dialog_title)
    matches = [b for b in child_buttons(dialog_title)
               if button_text in b["text"] and "Button" in b["class"]]
    if not matches:
        raise RuntimeError("找不到按钮 %s；现有控件: %s"
                           % (button_text, [b["text"] for b in child_buttons(dialog_title)]))
    hwnd = matches[0]["hwnd"]
    user32.SendMessageW(hwnd, BM_CLICK, 0, 0)
    time.sleep(wait)
    print("[CLICK_BUTTON]", matches[0]["text"])


def set_filename(dialog_title: str, path: str) -> None:
    """用 WM_SETTEXT 直接写文件名编辑框，避免 shell/剪贴板转义问题。"""
    w = find_window(dialog_title)
    if w is None:
        raise RuntimeError("找不到对话框: %s" % dialog_title)
    edits = [b for b in child_buttons(dialog_title)
             if "Edit" in b["class"] or "ComboBox" in b["class"]]
    if not edits:
        raise RuntimeError("找不到文件名编辑框；控件: %s"
                           % [(b["class"], b["text"]) for b in child_buttons(dialog_title)])
    hwnd = edits[-1]["hwnd"]
    buf = ctypes.create_unicode_buffer(path)
    user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT,
                                    wintypes.WPARAM, ctypes.c_void_p]
    user32.SendMessageW(hwnd, WM_SETTEXT, 0, ctypes.cast(buf, ctypes.c_void_p))
    print("[SET_FILENAME]", path, "hwnd", hwnd)
    time.sleep(0.3)


def click(x: int, y: int, wait: float = 0.4) -> None:
    """点击屏幕绝对坐标（截图坐标系），用于对话框按钮/工具栏下拉。"""
    MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
    user32.SetCursorPos(int(x), int(y))
    time.sleep(0.15)
    user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, None)
    time.sleep(0.05)
    user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, None)
    time.sleep(wait)


def shot(name: str) -> str:
    p = SHOT_DIR / name
    ImageGrab.grab().save(str(p))
    print("[SHOT]", p)
    return str(p)


def launch(which: str) -> None:
    if which == "vs":
        if not os.path.exists(VS_EXE):
            raise FileNotFoundError(VS_EXE)
        subprocess.Popen([VS_EXE, VS_SLN], close_fds=True)
        print("[LAUNCH] Visual Studio 2022 ->", VS_SLN)
    elif which == "matlab":
        if not os.path.exists(MATLAB_EXE):
            raise FileNotFoundError(MATLAB_EXE)
        subprocess.Popen([MATLAB_EXE], cwd=str(MATLAB_CWD), close_fds=True)
        print("[LAUNCH] MATLAB R2023b (desktop) cwd=", MATLAB_CWD)
    else:
        raise ValueError(which)


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("windows")
    p = sub.add_parser("launch")
    p.add_argument("--which", choices=["vs", "matlab"], required=True)
    p = sub.add_parser("activate")
    p.add_argument("--title", required=True)
    p.add_argument("--shot")
    p = sub.add_parser("keys")
    p.add_argument("--title")
    p.add_argument("--text", required=True)
    p.add_argument("--enter", action="store_true")
    p.add_argument("--shot")
    p = sub.add_parser("hotkey")
    p.add_argument("--title")
    p.add_argument("--combo", required=True)
    p.add_argument("--shot")
    p = sub.add_parser("wait")
    p.add_argument("--seconds", type=float, default=5)
    p.add_argument("--for-title", default=None)
    p.add_argument("--shot")
    p = sub.add_parser("shot")
    p.add_argument("--name", required=True)
    p = sub.add_parser("click")
    p.add_argument("--x", type=int, required=True)
    p.add_argument("--y", type=int, required=True)
    p.add_argument("--shot")
    sub.add_parser("runquickstart")
    sub.add_parser("openphoto")
    sub.add_parser("opensln")
    p = sub.add_parser("setfilename")
    p.add_argument("--title", required=True)
    p.add_argument("--path", required=True)
    p.add_argument("--open", action="store_true")
    p.add_argument("--shot")
    sub.add_parser("foreground")
    p = sub.add_parser("paste")
    p.add_argument("--title")
    p.add_argument("--text", required=True)
    p.add_argument("--enter", action="store_true")
    p.add_argument("--shot")
    p = sub.add_parser("buttons")
    p.add_argument("--title", required=True)
    p = sub.add_parser("clickbutton")
    p.add_argument("--title", required=True)
    p.add_argument("--button", required=True)
    p.add_argument("--shot")

    a = ap.parse_args()
    if a.cmd == "windows":
        for w in list_windows():
            print("%8d  %s" % (w["pid"], w["title"]))
    elif a.cmd == "launch":
        launch(a.which)
    elif a.cmd == "activate":
        w = activate(a.title)
        print("[ACTIVE]", w["title"])
        if a.shot:
            shot(a.shot)
    elif a.cmd == "keys":
        if a.title:
            activate(a.title)
        type_text(a.text)
        if a.enter:
            press(VK_RETURN)
        print("[TYPED]", a.text[:80])
        if a.shot:
            shot(a.shot)
    elif a.cmd == "hotkey":
        if a.title:
            activate(a.title)
        hotkey(a.combo)
        print("[HOTKEY]", a.combo)
        if a.shot:
            shot(a.shot)
    elif a.cmd == "wait":
        if a.for_title:
            deadline = time.time() + a.seconds
            found = None
            while time.time() < deadline:
                found = find_window(a.for_title)
                if found:
                    break
                time.sleep(1)
            print("[WAIT]", "FOUND " + found["title"] if found else "TIMEOUT")
        else:
            time.sleep(a.seconds)
            print("[WAIT] %.1fs" % a.seconds)
        if a.shot:
            shot(a.shot)
    elif a.cmd == "shot":
        shot(a.name)
    elif a.cmd == "click":
        click(a.x, a.y)
        print("[CLICK]", a.x, a.y)
        if a.shot:
            shot(a.shot)
    elif a.cmd == "runquickstart":
        # 在 MATLAB GUI 命令窗口里执行 quickstart；路径用模块常量，避开 shell 转义。
        activate("MATLAB R2023b")
        click(300, 1160, wait=0.3)          # 命令窗口 >> 输入行（不是标题栏）
        cmd = "cd('" + str(MATLAB_CWD) + "'); quickstart"
        paste(cmd)
        press(VK_RETURN)
        print("[RUNQUICKSTART]", cmd)
        time.sleep(18)
        shot("61_matlab_quickstart_result.png")
    elif a.cmd == "openphoto":
        # 精确找 class == 'Edit' 的文件名控件，WM_SETTEXT 写内置常量路径
        activate("打开文件")
        edits = [b for b in child_buttons("打开文件") if b["class"] == "Edit"]
        if not edits:
            raise RuntimeError("找不到文件名 Edit 控件")
        buf = ctypes.create_unicode_buffer(PHOTO_FRAME_PNG)
        user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT,
                                        wintypes.WPARAM, ctypes.c_void_p]
        user32.SendMessageW(edits[0]["hwnd"], WM_SETTEXT, 0,
                            ctypes.cast(buf, ctypes.c_void_p))
        print("[OPENPHOTO]", PHOTO_FRAME_PNG, "hwnd", edits[0]["hwnd"])
        time.sleep(0.4)
        shot("56_photo_path_set.png")
        click_button("打开文件", "打开(&O)")
    elif a.cmd == "opensln":
        # 用模块常量（正确反斜杠）粘贴，避开 shell 把 \v \P 吃掉的问题
        activate("打开文件")
        click(300, 615, wait=0.2)
        paste(VS_SLN)
        print("[OPENSLN] pasted", VS_SLN)
        shot("38_sln_path_typed.png")
        click_button("打开文件", "打开(&O)")
    elif a.cmd == "setfilename":
        set_filename(a.title, a.path)
        if a.open:
            click_button(a.title, "打开(&O)")
        if a.shot:
            shot(a.shot)
    elif a.cmd == "foreground":
        h = user32.GetForegroundWindow()
        n = user32.GetWindowTextLengthW(h)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(h, buf, n + 1)
        print("[FG]", h, buf.value)
    elif a.cmd == "paste":
        if a.title:
            activate(a.title)
        paste(a.text)
        if a.enter:
            press(VK_RETURN)
        print("[PASTED]", a.text[:80])
        if a.shot:
            shot(a.shot)
    elif a.cmd == "buttons":
        for b in child_buttons(a.title):
            print("%10d  %-22s %s" % (b["hwnd"], b["class"], b["text"]))
    elif a.cmd == "clickbutton":
        click_button(a.title, a.button)
        if a.shot:
            shot(a.shot)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
